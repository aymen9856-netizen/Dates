import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Package, ShoppingCart, Users, TrendingUp, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { formatPrice, formatNumber } from '@/utils/format';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from '@/types';
import type { Order, Product } from '@/types';

interface DashboardStats {
  totalProducts: number;
  totalOrders: number;
  totalCustomers: number;
  totalRevenue: number;
  pendingOrders: number;
  lowStock: number;
}

const AdminDashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [topProducts, setTopProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/dashboard/stats').then(r => r.json()),
      fetch('/api/dashboard/recent-orders').then(r => r.json()),
      fetch('/api/dashboard/top-products').then(r => r.json()),
    ]).then(([statsData, ordersData, productsData]) => {
      if (statsData.success) setStats(statsData.data);
      if (ordersData.success) setRecentOrders(ordersData.data);
      if (productsData.success) setTopProducts(productsData.data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="p-8"><LoadingSpinner /></div>;

  const statCards = [
    { title: 'إجمالي المنتجات', value: stats?.totalProducts || 0, icon: <Package size={24} />, color: 'bg-blue-50 text-blue-600', trend: '+5%' },
    { title: 'إجمالي الطلبات', value: stats?.totalOrders || 0, icon: <ShoppingCart size={24} />, color: 'bg-green-50 text-green-600', trend: '+12%' },
    { title: 'إجمالي العملاء', value: stats?.totalCustomers || 0, icon: <Users size={24} />, color: 'bg-purple-50 text-purple-600', trend: '+8%' },
    { title: 'إجمالي المبيعات', value: formatPrice(stats?.totalRevenue || 0), icon: <DollarSign size={24} />, color: 'bg-oasis-50 text-oasis-600', trend: '+15%' },
  ];

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-oasis-900">لوحة التحكم</h1>
        <span className="text-sand-500">{new Date().toLocaleDateString('ar-SA')}</span>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card-oasis p-6"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl ${card.color} flex items-center justify-center`}>
                {card.icon}
              </div>
              <span className="flex items-center gap-1 text-green-600 text-sm font-semibold">
                <ArrowUpRight size={14} />
                {card.trend}
              </span>
            </div>
            <p className="text-2xl font-bold text-oasis-900 mb-1">{card.value}</p>
            <p className="text-sm text-sand-500">{card.title}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="card-oasis p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-oasis-900">آخر الطلبات</h2>
            <Link to="/admin/orders" className="text-oasis-600 hover:text-oasis-700 text-sm font-semibold">
              عرض الكل
            </Link>
          </div>
          <div className="space-y-3">
            {recentOrders.slice(0, 5).map(order => (
              <div key={order.id} className="flex items-center justify-between p-3 rounded-xl bg-sand-50">
                <div>
                  <p className="font-semibold text-sm text-oasis-900">{order.id.slice(0, 12)}...</p>
                  <p className="text-xs text-sand-500">{order.customerName}</p>
                </div>
                <div className="text-left">
                  <p className="font-semibold text-sm">{formatPrice(order.total)}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${ORDER_STATUS_COLORS[order.status]}`}>
                    {ORDER_STATUS_LABELS[order.status]}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Top Products */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="card-oasis p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-oasis-900">أفضل المنتجات مبيعاً</h2>
            <Link to="/admin/products" className="text-oasis-600 hover:text-oasis-700 text-sm font-semibold">
              عرض الكل
            </Link>
          </div>
          <div className="space-y-3">
            {topProducts.slice(0, 5).map((product, i) => (
              <div key={product.id} className="flex items-center gap-4 p-3 rounded-xl bg-sand-50">
                <span className="w-8 h-8 rounded-full bg-oasis-100 flex items-center justify-center text-oasis-700 font-bold text-sm">
                  {i + 1}
                </span>
                <img src={product.mainImage} alt={product.name} className="w-10 h-10 rounded-lg object-cover bg-sand-200" />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-oasis-900 truncate">{product.name}</p>
                  <p className="text-xs text-sand-500">{product.sales} مبيعة</p>
                </div>
                <span className="font-semibold text-sm">{formatPrice(product.price)}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
