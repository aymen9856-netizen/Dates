import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Leaf, Users, Award, Globe } from 'lucide-react';
import { setSEO } from '@/utils/seo';

const AboutPage: React.FC = () => {
  useEffect(() => {
    setSEO({
      title: 'عن المزرعة - مزرعة الواحات',
      description: 'تعرف على قصة مزرعة الواحات ورحلتنا في إنتاج أفضل أنواع التمور السعودية الفاخرة.',
    });
  }, []);

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        {/* Hero */}
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">قصتنا</span>
          <h1 className="text-4xl md:text-5xl font-bold text-oasis-900 mb-6">مزرعة الواحات</h1>
          <p className="text-lg text-sand-600 max-w-3xl mx-auto leading-relaxed">
            منذ عام 2009، نزرع وننتج أجود أنواع التمور في منطقة القصيم. 
            نؤمن بأن التمر ليس مجرد منتج، بل هو تراث وهوية وثقافة عربية أصيلة.
          </p>
        </div>

        {/* Story */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <div className="absolute -inset-4 bg-oasis-100 rounded-3xl transform -rotate-2" />
              <div className="relative aspect-[4/3] bg-oasis-200 rounded-3xl flex items-center justify-center overflow-hidden">
                <span className="text-9xl">🌴</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="text-3xl font-bold text-oasis-900">بداية الرحلة</h2>
            <p className="text-sand-600 leading-relaxed text-lg">
              بدأت قصتنا في منطقة القصيم، حيث الأرض الخصبة والمناخ المثالي لزراعة النخيل. 
              كان حلمنا بسيطاً: إنتاج أفضل أنواع التمور التي تعكس عراقة هذه الأرض وتراثها.
            </p>
            <p className="text-sand-600 leading-relaxed">
              على مدار 15 عاماً، توسعت مزارعنا وطورنا أساليبنا. اليوم، نملك أكثر من 10,000 نخلة 
              تنتج سنوياً أكثر من 100,000 كجم من التمور الفاخرة.
            </p>
            <p className="text-sand-600 leading-relaxed">
              نلتزم بالزراعة العضوية والمستدامة. نستخدم المياه الجوفية النقية ونعتمد على الطرق الطبيعية 
              في العناية بالنخيل والحصاد. كل تمرة تحمل قصة عناية واهتمام.
            </p>
          </motion.div>
        </div>

        {/* Values */}
        <div className="mb-24">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-oasis-900 mb-4">قيمنا</h2>
            <p className="text-sand-600 max-w-2xl mx-auto">
              نلتزم بمبادئنا في كل خطوة من خطوات الإنتاج
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Leaf size={32} />,
                title: 'الجودة أولاً',
                desc: 'لا نساوم أبداً على الجودة. كل تمرة تمر بفحص دقيق قبل التغليف.',
              },
              {
                icon: <Users size={32} />,
                title: 'رضا العملاء',
                desc: 'نضع رضا عملائنا في صلب أولوياتنا ونسعى دائماً لتجاوز توقعاتهم.',
              },
              {
                icon: <Award size={32} />,
                title: 'التميز',
                desc: 'نسعى للتميز في كل تفصيل، من الزراعة وحتى خدمة ما بعد البيع.',
              },
              {
                icon: <Globe size={32} />,
                title: 'المسؤولية البيئية',
                desc: 'نلتزم بالممارسات الزراعية المستدامة لحماية بيئتنا للأجيال القادمة.',
              },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card-oasis p-8 text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-oasis-50 flex items-center justify-center text-oasis-600 mx-auto mb-4">
                  {item.icon}
                </div>
                <h3 className="font-bold text-xl text-oasis-900 mb-3">{item.title}</h3>
                <p className="text-sand-500">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Gallery */}
        <div className="mb-24">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-oasis-900 mb-4">معرض الصور</h2>
            <p className="text-sand-600">لمحات من مزارعنا ومراحل الإنتاج</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="aspect-square bg-oasis-100 rounded-xl overflow-hidden"
              >
                <div className="w-full h-full flex items-center justify-center bg-oasis-50">
                  <span className="text-4xl">{['🌴', '🌿', '🏜️', '📦', '🌾', '🍯', '🎁', '☀️'][i - 1]}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
