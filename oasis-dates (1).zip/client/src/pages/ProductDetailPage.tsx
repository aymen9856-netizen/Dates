import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart, Share2, Link as LinkIcon, Check, Truck, Package, RotateCcw, Minus, Plus, Heart, ChevronLeft } from 'lucide-react';
import { ImageGallery } from '@/components/ImageGallery';
import { ProductCard } from '@/components/ProductCard';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { useCart } from '@/contexts/CartContext';
import { setSEO } from '@/utils/seo';
import { formatPrice } from '@/utils/format';
import type { Product } from '@/types';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addItem, items } = useCart();
  const [product, setProduct] = useState<Product | null>(null);
  const [similarProducts, setSimilarProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [copied, setCopied] = useState(false);

  const cartItem = items.find(item => item.product.id === id);
  const maxQuantity = product ? product.stock - (cartItem?.quantity || 0) : 0;

  useEffect(() => {
    if (!id) return;

    fetch(`/api/products/${id}`)
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setProduct(data.data);
          setSEO({
            title: `${data.data.name} - مزرعة الواحات`,
            description: data.data.description,
            ogImage: data.data.mainImage,
          });

          // Fetch similar products
          fetch(`/api/products`)
            .then(r => r.json())
            .then(allData => {
              if (allData.success) {
                const similar = allData.data
                  .filter((p: Product) => p.id !== id && p.category === data.data.category)
                  .slice(0, 4);
                setSimilarProducts(similar);
              }
            });
        }
      })
      .finally(() => setLoading(false));
  }, [id]);

  const handleShare = async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = url;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleWhatsApp = () => {
    if (!product) return;
    const text = `مرحباً، أريد الاستفسار عن: ${product.name} - ${formatPrice(product.price)}`;
    window.open(`https://wa.me/966551234567?text=${encodeURIComponent(text)}`, '_blank');
  };

  if (loading) return <div className="pt-32 pb-16"><LoadingSpinner /></div>;
  if (!product) return <div className="pt-32 pb-16 text-center">المنتج غير موجود</div>;

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-sand-500 mb-6">
          <Link to="/" className="hover:text-oasis-600 transition-colors">الرئيسية</Link>
          <ChevronLeft size={14} />
          <Link to="/products" className="hover:text-oasis-600 transition-colors">المنتجات</Link>
          <ChevronLeft size={14} />
          <span className="text-oasis-900">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Gallery */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <ImageGallery images={product.images} productName={product.name} />
          </motion.div>

          {/* Details */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="px-3 py-1 rounded-full bg-oasis-100 text-oasis-700 text-sm font-medium">
                  {product.category}
                </span>
                <span className="px-3 py-1 rounded-full bg-sand-100 text-sand-600 text-sm">
                  {product.quality}
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-oasis-900 mb-4">{product.name}</h1>
              <p className="text-sand-600 leading-relaxed text-lg">{product.description}</p>
            </div>

            {/* Price */}
            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold text-oasis-700">{formatPrice(product.price)}</span>
              {product.oldPrice && (
                <>
                  <span className="text-xl text-sand-400 line-through">{formatPrice(product.oldPrice)}</span>
                  <span className="px-3 py-1 rounded-full bg-red-100 text-red-600 text-sm font-bold">
                    وفر {discount}%
                  </span>
                </>
              )}
            </div>

            {/* Info */}
            <div className="grid grid-cols-2 gap-4 py-6 border-y border-sand-200">
              <div>
                <span className="text-sand-500 text-sm">الوزن</span>
                <p className="font-semibold text-oasis-900">{product.weight}</p>
              </div>
              <div>
                <span className="text-sand-500 text-sm">المخزون</span>
                <p className="font-semibold text-oasis-900">{product.stock} وحدة</p>
              </div>
              <div>
                <span className="text-sand-500 text-sm">بلد الإنتاج</span>
                <p className="font-semibold text-oasis-900">{product.country}</p>
              </div>
              <div>
                <span className="text-sand-500 text-sm">المنطقة</span>
                <p className="font-semibold text-oasis-900">{product.region}</p>
              </div>
              <div>
                <span className="text-sand-500 text-sm">SKU</span>
                <p className="font-semibold text-oasis-900">{product.sku}</p>
              </div>
              <div>
                <span className="text-sand-500 text-sm">النوع</span>
                <p className="font-semibold text-oasis-900">{product.type}</p>
              </div>
            </div>

            {/* Quantity & Add to cart */}
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center border border-sand-200 rounded-xl overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-3 hover:bg-sand-50 transition-colors"
                >
                  <Minus size={18} />
                </button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(maxQuantity, quantity + 1))}
                  disabled={quantity >= maxQuantity}
                  className="p-3 hover:bg-sand-50 transition-colors disabled:opacity-50"
                >
                  <Plus size={18} />
                </button>
              </div>

              <button
                onClick={() => {
                  for (let i = 0; i < quantity; i++) {
                    addItem(product);
                  }
                }}
                disabled={maxQuantity <= 0}
                className="flex-1 btn-primary gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ShoppingCart size={20} />
                {maxQuantity <= 0 ? 'نفذت الكمية' : 'أضف إلى السلة'}
              </button>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2 rounded-xl border border-sand-200 hover:bg-sand-50 transition-colors text-sm"
              >
                {copied ? <Check size={16} className="text-green-500" /> : <LinkIcon size={16} />}
                {copied ? 'تم النسخ' : 'نسخ الرابط'}
              </button>
              <button
                onClick={handleWhatsApp}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-green-50 text-green-700 hover:bg-green-100 transition-colors text-sm"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                استفسار واتساب
              </button>
            </div>

            {/* Info boxes */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              {[
                { icon: <Truck size={20} />, text: 'شحن سريع' },
                { icon: <Package size={20} />, text: 'تغليف فاخر' },
                { icon: <RotateCcw size={20} />, text: 'ضمان استرجاع' },
              ].map(item => (
                <div key={item.text} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-sand-50 text-center">
                  <span className="text-oasis-600">{item.icon}</span>
                  <span className="text-sm font-medium text-sand-700">{item.text}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Similar Products */}
        {similarProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-oasis-900 mb-6">منتجات مشابهة</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {similarProducts.map((p, i) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <ProductCard product={p} />
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;
