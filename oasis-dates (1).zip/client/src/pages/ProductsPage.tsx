import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal, X, Grid3X3, List } from 'lucide-react';
import { ProductCard } from '@/components/ProductCard';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { setSEO } from '@/utils/seo';
import type { Product, Filters } from '@/types';

const ProductsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [types, setTypes] = useState<string[]>([]);
  const [qualities, setQualities] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState<Filters>({
    search: searchParams.get('q') || '',
    category: searchParams.get('category') || '',
    type: '',
    quality: '',
    minPrice: 0,
    maxPrice: 1000,
    sortBy: 'newest',
  });

  useEffect(() => {
    setSEO({
      title: 'المنتجات - مزرعة الواحات',
      description: 'تصفح مجموعتنا الواسعة من التمور الفاخرة. سكري، خلاص، صقعي، مجدول وغيرها.',
    });

    Promise.all([
      fetch('/api/products').then(r => r.json()),
      fetch('/api/products/categories').then(r => r.json()),
    ]).then(([productsData, catsData]) => {
      if (productsData.success) {
        setProducts(productsData.data);
        // Extract unique types and qualities from products
        const allTypes = [...new Set(productsData.data.map((p: Product) => p.type))];
        const allQualities = [...new Set(productsData.data.map((p: Product) => p.quality))];
        setTypes(allTypes as string[]);
        setQualities(allQualities as string[]);
      }
      if (catsData.success) setCategories(catsData.data);
      setLoading(false);
    });
  }, []);

  const handleSearch = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (filters.search) {
      fetch(`/api/products/search?q=${encodeURIComponent(filters.search)}`)
        .then(r => r.json())
        .then(data => {
          if (data.success) setProducts(data.data);
        });
    } else {
      fetch('/api/products')
        .then(r => r.json())
        .then(data => {
          if (data.success) setProducts(data.data);
        });
    }
  }, [filters.search]);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (filters.category) {
      result = result.filter(p => p.category === filters.category);
    }
    if (filters.type) {
      result = result.filter(p => p.type === filters.type);
    }
    if (filters.quality) {
      result = result.filter(p => p.quality === filters.quality);
    }
    if (filters.minPrice > 0) {
      result = result.filter(p => p.price >= filters.minPrice);
    }
    if (filters.maxPrice < 1000) {
      result = result.filter(p => p.price <= filters.maxPrice);
    }

    switch (filters.sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'popular':
        result.sort((a, b) => b.views - a.views);
        break;
      case 'sales':
        result.sort((a, b) => b.sales - a.sales);
        break;
    }

    return result;
  }, [products, filters]);

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      type: '',
      quality: '',
      minPrice: 0,
      maxPrice: 1000,
      sortBy: 'newest',
    });
    setSearchParams({});
  };

  const hasActiveFilters = filters.category || filters.type || filters.quality || filters.minPrice > 0 || filters.maxPrice < 1000;

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-oasis-900 mb-2">منتجاتنا</h1>
          <p className="text-sand-500">اكتشف تشكيلتنا الواسعة من التمور الفاخرة</p>
        </div>

        {/* Search & Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <form onSubmit={handleSearch} className="flex-1 relative">
            <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-sand-400" />
            <input
              type="text"
              placeholder="ابحث عن تمر..."
              value={filters.search}
              onChange={e => setFilters(prev => ({ ...prev, search: e.target.value }))}
              className="w-full pr-12 pl-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500 focus:border-transparent"
            />
          </form>

          <div className="flex gap-3">
            <select
              value={filters.sortBy}
              onChange={e => setFilters(prev => ({ ...prev, sortBy: e.target.value as Filters['sortBy'] }))}
              className="px-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500"
            >
              <option value="newest">الأحدث</option>
              <option value="price-asc">السعر: من الأقل</option>
              <option value="price-desc">السعر: من الأعلى</option>
              <option value="popular">الأكثر مشاهدة</option>
              <option value="sales">الأكثر مبيعاً</option>
            </select>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 py-3 rounded-xl border flex items-center gap-2 transition-colors ${
                showFilters || hasActiveFilters
                  ? 'bg-oasis-50 border-oasis-300 text-oasis-700'
                  : 'border-sand-200 bg-white text-sand-600'
              }`}
            >
              <SlidersHorizontal size={18} />
              <span className="hidden sm:inline">الفلاتر</span>
              {hasActiveFilters && <span className="w-2 h-2 rounded-full bg-oasis-500" />}
            </button>

            <div className="hidden md:flex border border-sand-200 rounded-xl overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-3 ${viewMode === 'grid' ? 'bg-oasis-50 text-oasis-700' : 'bg-white text-sand-400'}`}
              >
                <Grid3X3 size={18} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-3 ${viewMode === 'list' ? 'bg-oasis-50 text-oasis-700' : 'bg-white text-sand-400'}`}
              >
                <List size={18} />
              </button>
            </div>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-white rounded-xl border border-sand-200 p-6 mb-8"
          >
            <div className="grid md:grid-cols-4 gap-6">
              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">التصنيف</label>
                <select
                  value={filters.category}
                  onChange={e => setFilters(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                >
                  <option value="">الكل</option>
                  {categories.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">النوع</label>
                <select
                  value={filters.type}
                  onChange={e => setFilters(prev => ({ ...prev, type: e.target.value }))}
                  className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                >
                  <option value="">الكل</option>
                  {types.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">الجودة</label>
                <select
                  value={filters.quality}
                  onChange={e => setFilters(prev => ({ ...prev, quality: e.target.value }))}
                  className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                >
                  <option value="">الكل</option>
                  {qualities.map(q => (
                    <option key={q} value={q}>{q}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">نطاق السعر</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    placeholder="من"
                    value={filters.minPrice || ''}
                    onChange={e => setFilters(prev => ({ ...prev, minPrice: Number(e.target.value) }))}
                    className="w-full px-3 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                  />
                  <span className="text-sand-400">-</span>
                  <input
                    type="number"
                    placeholder="إلى"
                    value={filters.maxPrice === 1000 ? '' : filters.maxPrice}
                    onChange={e => setFilters(prev => ({ ...prev, maxPrice: Number(e.target.value) || 1000 }))}
                    className="w-full px-3 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                  />
                </div>
              </div>
            </div>

            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="mt-4 text-sm text-red-500 hover:text-red-600 flex items-center gap-1"
              >
                <X size={14} />
                مسح الفلاتر
              </button>
            )}
          </motion.div>
        )}

        {/* Results count */}
        <div className="mb-6 text-sand-500">
          {filteredProducts.length} منتج
        </div>

        {/* Products Grid */}
        {loading ? (
          <LoadingSpinner />
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-sand-500 text-lg">لا توجد منتجات مطابقة للبحث</p>
            <button onClick={clearFilters} className="mt-4 text-oasis-600 hover:underline">
              عرض جميع المنتجات
            </button>
          </div>
        ) : (
          <div className={`grid gap-6 ${
            viewMode === 'grid' 
              ? 'sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
              : 'grid-cols-1'
          }`}>
            {filteredProducts.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;
