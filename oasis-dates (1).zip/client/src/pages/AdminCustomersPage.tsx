import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Phone, Mail, ShoppingBag, MapPin } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { formatNumber } from '@/utils/format';
import type { Customer } from '@/types';

const AdminCustomersPage: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/customers')
      .then(r => r.json())
      .then(data => {
        if (data.success) setCustomers(data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search) ||
    c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-oasis-900 mb-8">العملاء</h1>

      <div className="relative mb-6">
        <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-sand-400" />
        <input
          type="text"
          placeholder="البحث في العملاء..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pr-12 pl-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500"
        />
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCustomers.map((customer, i) => (
            <motion.div
              key={customer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="card-oasis p-6"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-oasis-100 flex items-center justify-center text-oasis-700 font-bold text-lg">
                  {customer.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-oasis-900">{customer.name}</h3>
                  <p className="text-sm text-sand-500">عميل منذ {new Date(customer.createdAt).getFullYear()}</p>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-sand-600">
                  <Phone size={14} />
                  <span>{customer.phone}</span>
                </div>
                {customer.email && (
                  <div className="flex items-center gap-2 text-sand-600">
                    <Mail size={14} />
                    <span>{customer.email}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sand-600">
                  <ShoppingBag size={14} />
                  <span>{customer.orders.length} طلب</span>
                </div>
                <div className="flex items-center gap-2 text-sand-600">
                  <MapPin size={14} />
                  <span>{customer.addresses.length} عنوان</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminCustomersPage;
