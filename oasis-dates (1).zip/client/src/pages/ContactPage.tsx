import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle } from 'lucide-react';
import { setSEO } from '@/utils/seo';

const ContactPage: React.FC = () => {
  const [sent, setSent] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });

  useEffect(() => {
    setSEO({
      title: 'تواصل معنا - مزرعة الواحات',
      description: 'تواصل مع مزرعة الواحات للاستفسارات والطلبات الخاصة.',
    });
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, send to API
    setSent(true);
    setTimeout(() => setSent(false), 3000);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">نحن هنا لمساعدتك</span>
          <h1 className="text-4xl md:text-5xl font-bold text-oasis-900 mb-6">تواصل معنا</h1>
          <p className="text-lg text-sand-600 max-w-2xl mx-auto">
            لديك استفسار أو طلب خاص؟ لا تتردد في التواصل معنا
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="card-oasis p-8">
              <h2 className="text-2xl font-bold text-oasis-900 mb-6">معلومات التواصل</h2>
              <div className="space-y-6">
                {[
                  { icon: <Phone size={24} />, title: 'الهاتف', info: '+966 55 123 4567', link: 'tel:+966551234567' },
                  { icon: <Mail size={24} />, title: 'البريد الإلكتروني', info: 'info@oasis-dates.com', link: 'mailto:info@oasis-dates.com' },
                  { icon: <MapPin size={24} />, title: 'العنوان', info: 'القصيم، المملكة العربية السعودية', link: '#' },
                  { icon: <Clock size={24} />, title: 'ساعات العمل', info: 'السبت - الخميس: 8 ص - 10 م', link: '#' },
                ].map(item => (
                  <a
                    key={item.title}
                    href={item.link}
                    className="flex items-start gap-4 group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-oasis-50 flex items-center justify-center text-oasis-600 group-hover:bg-oasis-600 group-hover:text-white transition-colors">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-oasis-900">{item.title}</h3>
                      <p className="text-sand-500">{item.info}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/966551234567"
              target="_blank"
              rel="noopener noreferrer"
              className="card-oasis p-8 flex items-center gap-6 hover:shadow-lg transition-shadow block"
            >
              <div className="w-16 h-16 rounded-2xl bg-green-100 flex items-center justify-center text-green-600">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <div>
                <h3 className="font-bold text-lg text-oasis-900">تواصل عبر واتساب</h3>
                <p className="text-sand-500">رد سريع على استفساراتك</p>
              </div>
            </a>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="card-oasis p-8">
              <h2 className="text-2xl font-bold text-oasis-900 mb-6">أرسل لنا رسالة</h2>

              {sent ? (
                <div className="text-center py-12">
                  <CheckCircle size={64} className="text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-oasis-900 mb-2">تم الإرسال بنجاح!</h3>
                  <p className="text-sand-500">سنقوم بالرد عليك في أقرب وقت</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-2">الاسم</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                      placeholder="اسمك الكامل"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-2">البريد الإلكتروني</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-2">رقم الهاتف</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                      placeholder="+966 5X XXX XXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-2">الرسالة</label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={e => setFormData(prev => ({ ...prev, message: e.target.value }))}
                      className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
                      placeholder="اكتب رسالتك هنا..."
                    />
                  </div>
                  <button type="submit" className="w-full btn-primary gap-2">
                    <Send size={18} />
                    إرسال الرسالة
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
