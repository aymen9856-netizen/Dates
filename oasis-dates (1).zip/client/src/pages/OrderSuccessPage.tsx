import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Package, Truck, Phone, Home, ArrowLeft, Printer } from 'lucide-react';
import { formatPrice, formatDate } from '@/utils/format';
import { ORDER_STATUS_LABELS } from '@/types';
import type { Order } from '@/types';

const OrderSuccessPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/orders/${id}`)
      .then(r => r.json())
      .then(data => {
        if (data.success) setOrder(data.data);
      })
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="pt-32 text-center">جاري التحميل...</div>;
  if (!order) return <div className="pt-32 text-center">الطلب غير موجود</div>;

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis max-w-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center mb-8"
        >
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={40} className="text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-oasis-900 mb-2">تم تأكيد طلبك!</h1>
          <p className="text-sand-500">رقم الطلب: <span className="font-mono font-bold text-oasis-700">{order.id}</span></p>
        </motion.div>

        <div className="card-oasis p-8 space-y-6">
          {/* Status */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-oasis-50">
            <span className="text-sand-600">حالة الطلب</span>
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
              order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
              order.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
              'bg-green-100 text-green-800'
            }`}>
              {ORDER_STATUS_LABELS[order.status]}
            </span>
          </div>

          {/* Items */}
          <div>
            <h3 className="font-bold text-oasis-900 mb-4">المنتجات</h3>
            <div className="space-y-3">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-sand-50">
                  <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover bg-sand-200" />
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-oasis-900">{item.name}</p>
                    <p className="text-xs text-sand-500">{item.weight} × {item.quantity}</p>
                  </div>
                  <span className="font-semibold text-oasis-700">{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div className="border-t border-sand-200 pt-4 space-y-2">
            <div className="flex justify-between text-sand-600">
              <span>المجموع الفرعي</span>
              <span>{formatPrice(order.subtotal)}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>الخصم</span>
                <span>-{formatPrice(order.discount)}</span>
              </div>
            )}
            <div className="flex justify-between text-sand-600">
              <span>الشحن</span>
              <span>{order.shipping === 0 ? 'مجاني' : formatPrice(order.shipping)}</span>
            </div>
            <div className="flex justify-between text-xl font-bold text-oasis-900 pt-2 border-t border-sand-200">
              <span>الإجمالي</span>
              <span>{formatPrice(order.total)}</span>
            </div>
          </div>

          {/* Customer info */}
          <div className="border-t border-sand-200 pt-4">
            <h3 className="font-bold text-oasis-900 mb-3">بيانات العميل</h3>
            <div className="space-y-2 text-sm">
              <p className="flex items-center gap-2 text-sand-600">
                <Home size={14} />
                {order.customerName}
              </p>
              <p className="flex items-center gap-2 text-sand-600">
                <Phone size={14} />
                {order.customerPhone}
              </p>
              <p className="text-sand-600">{order.address}, {order.city}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-3 pt-4">
            <Link to="/products" className="flex-1 btn-primary text-center">
              <ArrowLeft size={18} />
              مواصلة التسوق
            </Link>
            <a
              href={`/api/orders/${order.id}/invoice`}
              target="_blank"
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg border border-sand-200 hover:bg-sand-50 transition-colors"
            >
              <Printer size={18} />
              طباعة الفاتورة
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccessPage;
