import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Droplets, Package, Truck, ShieldCheck, Thermometer } from 'lucide-react';
import { setSEO } from '@/utils/seo';

const PackagingPage: React.FC = () => {
  useEffect(() => {
    setSEO({
      title: 'طرق التعبئة - مزرعة الواحات',
      description: 'تعرف على مراحل الفرز والتنظيف والتعبئة في مزرعة الواحات.',
    });
  }, []);

  const steps = [
    {
      icon: <Search size={32} />,
      title: 'الفرز اليدوي',
      desc: 'يقوم فريقنا المتخصص بفرز التمور يدوياً واحداً تلو الآخر. نختار فقط التمور ذات الحجم المثالي واللون الموحد والنضج المناسب. أي تمرة لا تلبي معاييرنا تُستبعد فوراً.',
      color: 'bg-blue-50 text-blue-600',
    },
    {
      icon: <Droplets size={32} />,
      title: 'التنظيف والتعقيم',
      desc: 'تمر التمور بعملية تنظيف دقيقة باستخدام مياه نقية ومعالجة بالأشعة فوق البنفسجية للتعقيم. نضمن إزالة أي شوائب مع الحفاظ على الطبقة الوقائية الطبيعية للتمر.',
      color: 'bg-cyan-50 text-cyan-600',
    },
    {
      icon: <Thermometer size={32} />,
      title: 'التبريد والتخزين',
      desc: 'نخزن التمور في مخازن مبردة بدرجة حرارة محكمة (2-4 درجات مئوية) ورطوبة مناسبة. هذا يضمن الحفاظ على الطراوة والنكهة الطبيعية حتى لحظة التعبئة.',
      color: 'bg-indigo-50 text-indigo-600',
    },
    {
      icon: <Package size={32} />,
      title: 'التعبئة الفاخرة',
      desc: 'نعبئ التمور في عبوات متعددة الأحجام حسب طلب العميل. نستخدم مواد تغليف عالية الجودة تحافظ على التمور وتحميها من الرطوبة والهواء. التغليف أنيق ومناسب للهدايا.',
      color: 'bg-oasis-50 text-oasis-600',
    },
    {
      icon: <ShieldCheck size={32} />,
      title: 'فحص الجودة النهائي',
      desc: 'قبل الشحن، يتم فحص كل طلب للتأكد من مطابقته للمواصفات. نتحقق من الوزن، الجودة، التغليف، وتاريخ الإنتاج. لا يغادر المستودع أي طلب لم يجتز الفحص بنسبة 100%.',
      color: 'bg-green-50 text-green-600',
    },
    {
      icon: <Truck size={32} />,
      title: 'الشحن والتوصيل',
      desc: 'نغلف الطلبات بعناية فائقة باستخدام مواد حماية مبطنة. نتعاون مع أفضل شركات الشحن لضمان وصول طلباتكم بأمان وفي أسرع وقت ممكن.',
      color: 'bg-amber-50 text-amber-600',
    },
  ];

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">الجودة في كل تفصيل</span>
          <h1 className="text-4xl md:text-5xl font-bold text-oasis-900 mb-6">مراحل التعبئة</h1>
          <p className="text-lg text-sand-600 max-w-3xl mx-auto leading-relaxed">
            نتابع كل مرحلة بعناية فائقة لضمان وصول أفضل جودة إليكم. 
            من لحظة قطف التمر من النخلة وحتى وصوله إلى باب منزلكم.
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-8">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`card-oasis p-8 ${i % 2 === 0 ? '' : 'md:mr-12'}`}
            >
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className={`w-16 h-16 rounded-2xl ${step.color} flex items-center justify-center shrink-0`}>
                  {step.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-3xl font-bold text-sand-200">0{i + 1}</span>
                    <h3 className="text-xl font-bold text-oasis-900">{step.title}</h3>
                  </div>
                  <p className="text-sand-600 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quality promise */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 bg-oasis-900 rounded-3xl p-8 md:p-12 text-center text-white"
        >
          <h2 className="text-2xl md:text-3xl font-bold mb-4">وعدنا لكم</h2>
          <p className="text-sand-300 max-w-2xl mx-auto text-lg leading-relaxed">
            نعدكم بأن كل تمرة تصلكم من مزرعة الواحات قد مرت بأعلى معايير الجودة. 
            إذا لم تكن راضياً عن جودة المنتج لأي سبب، نضمن استرداد كامل المبلغ.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default PackagingPage;
