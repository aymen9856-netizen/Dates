import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { HeroSection } from '@/components/HeroSection';
import { AboutSection } from '@/components/AboutSection';
import { FeaturesSection } from '@/components/FeaturesSection';
import { PackagingSection } from '@/components/PackagingSection';
import { TestimonialsSection } from '@/components/TestimonialsSection';
import { FAQSection } from '@/components/FAQSection';
import { ContactSection } from '@/components/ContactSection';
import { ProductCard } from '@/components/ProductCard';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { setSEO } from '@/utils/seo';
import type { Product } from '@/types';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setSEO({
      title: 'مزرعة الواحات - متجر التمور الفاخر',
      description: 'أفضل أنواع التمور السعودية الفاخرة من مزرعة الواحات. تمر سكري، خلاص، صقعي، مجدول وغيرها.',
      keywords: 'تمور، تمر، سكري، خلاص، صقعي، مزرعة الواحات، تمور فاخرة',
    });

    fetch('/api/products/featured')
      .then(r => r.json())
      .then(data => {
        if (data.success) setFeaturedProducts(data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <HeroSection />

      {/* Featured Products */}
      <section className="py-24 bg-sand-50">
        <div className="container-oasis">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="text-oasis-600 font-semibold mb-2 block">منتجاتنا المميزة</span>
              <h2 className="text-3xl md:text-4xl font-bold text-oasis-900">أفضل التمور الفاخرة</h2>
            </div>
            <Link to="/products" className="hidden md:flex items-center gap-2 text-oasis-600 hover:text-oasis-700 font-semibold transition-colors">
              عرض الكل
              <ArrowLeft size={20} />
            </Link>
          </div>

          {loading ? (
            <LoadingSpinner />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
          )}

          <div className="mt-8 text-center md:hidden">
            <Link to="/products" className="btn-primary">
              عرض جميع المنتجات
              <ArrowLeft size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="py-16 bg-oasis-900 text-white">
        <div className="container-oasis">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {[
              { value: '50,000+', label: 'عميل سعيد' },
              { value: '100,000+', label: 'كجم تمر سنوياً' },
              { value: '15+', label: 'سنة خبرة' },
              { value: '99%', label: 'نسبة الرضا' },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="text-3xl md:text-4xl font-bold text-oasis-400 mb-2">{stat.value}</div>
                <div className="text-sand-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <AboutSection />
      <FeaturesSection />
      <PackagingSection />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
    </div>
  );
};

export default HomePage;
