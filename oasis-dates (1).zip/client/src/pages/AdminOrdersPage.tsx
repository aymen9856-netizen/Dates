import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Eye, Printer, ChevronDown, Package, Truck, CheckCircle, XCircle, Clock, ChefHat } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { formatPrice, formatDate } from '@/utils/format';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from '@/types';
import type { Order, OrderStatus } from '@/types';

const statusOptions: { value: OrderStatus; label: string; icon: React.ReactNode }[] = [
  { value: 'pending', label: 'قيد الانتظار', icon: <Clock size={14} /> },
  { value: 'confirmed', label: 'تم التأكيد', icon: <CheckCircle size={14} /> },
  { value: 'preparing', label: 'جاري التحضير', icon: <ChefHat size={14} /> },
  { value: 'shipping', label: 'جاري الشحن', icon: <Truck size={14} /> },
  { value: 'delivered', label: 'تم التسليم', icon: <Package size={14} /> },
  { value: 'cancelled', label: 'ملغي', icon: <XCircle size={14} /> },
];

const AdminOrdersPage: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchOrders = () => {
    fetch('/api/orders')
      .then(r => r.json())
      .then(data => {
        if (data.success) setOrders(data.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const response = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      const data = await response.json();
      if (data.success) {
        fetchOrders();
        if (selectedOrder?.id === orderId) {
          setSelectedOrder({ ...selectedOrder, status });
        }
      }
    } catch {
      alert('حدث خطأ');
    }
  };

  const filteredOrders = orders.filter(o => {
    const matchesSearch = o.customerName.toLowerCase().includes(search.toLowerCase()) ||
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.customerPhone.includes(search);
    const matchesStatus = !statusFilter || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-oasis-900 mb-8">الطلبات</h1>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-sand-400" />
          <input
            type="text"
            placeholder="البحث في الطلبات..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pr-12 pl-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="px-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500"
        >
          <option value="">جميع الحالات</option>
          {statusOptions.map(s => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="card-oasis overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-sand-50 border-b border-sand-200">
                <tr>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">رقم الطلب</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">العميل</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">المبلغ</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">الحالة</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">التاريخ</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sand-100">
                {filteredOrders.map(order => (
                  <tr key={order.id} className="hover:bg-sand-50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm text-oasis-700">{order.id.slice(0, 12)}...</span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-semibold text-oasis-900">{order.customerName}</p>
                        <p className="text-xs text-sand-500">{order.customerPhone}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold">{formatPrice(order.total)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${ORDER_STATUS_COLORS[order.status]}`}>
                        {ORDER_STATUS_LABELS[order.status]}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-sand-500">{formatDate(order.createdAt)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-2 rounded-lg hover:bg-oasis-50 text-oasis-600 transition-colors"
                        >
                          <Eye size={16} />
                        </button>
                        <a
                          href={`/api/orders/${order.id}/invoice`}
                          target="_blank"
                          className="p-2 rounded-lg hover:bg-oasis-50 text-oasis-600 transition-colors"
                        >
                          <Printer size={16} />
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Order Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setSelectedOrder(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-sand-200 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-oasis-900">تفاصيل الطلب</h2>
                  <p className="text-sm text-sand-500">{selectedOrder.id}</p>
                </div>
                <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-sand-100 rounded-lg">
                  <XCircle size={20} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Status update */}
                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-2">تحديث الحالة</label>
                  <div className="flex flex-wrap gap-2">
                    {statusOptions.map(status => (
                      <button
                        key={status.value}
                        onClick={() => updateStatus(selectedOrder.id, status.value)}
                        className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                          selectedOrder.status === status.value
                            ? 'bg-oasis-600 text-white'
                            : 'bg-sand-100 text-sand-600 hover:bg-sand-200'
                        }`}
                      >
                        {status.icon}
                        {status.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Items */}
                <div>
                  <h3 className="font-bold text-oasis-900 mb-3">المنتجات</h3>
                  <div className="space-y-2">
                    {selectedOrder.items.map((item, i) => (
                      <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-sand-50">
                        <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover bg-sand-200" />
                        <div className="flex-1">
                          <p className="font-semibold text-sm">{item.name}</p>
                          <p className="text-xs text-sand-500">{item.weight} × {item.quantity}</p>
                        </div>
                        <span className="font-semibold">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="border-t border-sand-200 pt-4 space-y-2">
                  <div className="flex justify-between text-sand-600">
                    <span>المجموع الفرعي</span>
                    <span>{formatPrice(selectedOrder.subtotal)}</span>
                  </div>
                  {selectedOrder.discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>الخصم</span>
                      <span>-{formatPrice(selectedOrder.discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sand-600">
                    <span>الشحن</span>
                    <span>{selectedOrder.shipping === 0 ? 'مجاني' : formatPrice(selectedOrder.shipping)}</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-oasis-900 pt-2 border-t border-sand-200">
                    <span>الإجمالي</span>
                    <span>{formatPrice(selectedOrder.total)}</span>
                  </div>
                </div>

                {/* Customer info */}
                <div className="border-t border-sand-200 pt-4">
                  <h3 className="font-bold text-oasis-900 mb-3">بيانات العميل</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-sand-500">الاسم</span>
                      <p className="font-semibold">{selectedOrder.customerName}</p>
                    </div>
                    <div>
                      <span className="text-sand-500">الهاتف</span>
                      <p className="font-semibold">{selectedOrder.customerPhone}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-sand-500">العنوان</span>
                      <p className="font-semibold">{selectedOrder.address}, {selectedOrder.city}</p>
                    </div>
                    {selectedOrder.notes && (
                      <div className="col-span-2">
                        <span className="text-sand-500">ملاحظات</span>
                        <p className="font-semibold">{selectedOrder.notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminOrdersPage;
