import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Globe, Phone, Mail, MapPin, Facebook, Instagram, Twitter, Youtube } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import type { Settings } from '@/types';

const AdminSettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        if (data.success) setSettings(data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await response.json();
      if (data.success) {
        alert('تم الحفظ بنجاح');
      }
    } catch {
      alert('حدث خطأ');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-8"><LoadingSpinner /></div>;
  if (!settings) return <div className="p-8">خطأ في تحميل الإعدادات</div>;

  return (
    <div className="p-8 max-w-4xl">
      <h1 className="text-3xl font-bold text-oasis-900 mb-8">الإعدادات</h1>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* General */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-oasis p-6"
        >
          <h2 className="text-xl font-bold text-oasis-900 mb-6 flex items-center gap-2">
            <Globe size={20} />
            إعدادات عامة
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">اسم الموقع</label>
              <input
                value={settings.siteName}
                onChange={e => setSettings(prev => prev ? { ...prev, siteName: e.target.value } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-oasis-900 mb-1">وصف الموقع</label>
              <textarea
                rows={2}
                value={settings.siteDescription}
                onChange={e => setSettings(prev => prev ? { ...prev, siteDescription: e.target.value } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
              />
            </div>
          </div>
        </motion.div>

        {/* Contact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="card-oasis p-6"
        >
          <h2 className="text-xl font-bold text-oasis-900 mb-6 flex items-center gap-2">
            <Phone size={20} />
            معلومات التواصل
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">الهاتف</label>
              <input
                value={settings.contact.phone}
                onChange={e => setSettings(prev => prev ? { ...prev, contact: { ...prev.contact, phone: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">واتساب</label>
              <input
                value={settings.contact.whatsapp}
                onChange={e => setSettings(prev => prev ? { ...prev, contact: { ...prev.contact, whatsapp: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">البريد الإلكتروني</label>
              <input
                value={settings.contact.email}
                onChange={e => setSettings(prev => prev ? { ...prev, contact: { ...prev.contact, email: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">العنوان</label>
              <input
                value={settings.contact.address}
                onChange={e => setSettings(prev => prev ? { ...prev, contact: { ...prev.contact, address: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
          </div>
        </motion.div>

        {/* Social */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card-oasis p-6"
        >
          <h2 className="text-xl font-bold text-oasis-900 mb-6">روابط التواصل الاجتماعي</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">Facebook</label>
              <input
                value={settings.social.facebook}
                onChange={e => setSettings(prev => prev ? { ...prev, social: { ...prev.social, facebook: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">Twitter</label>
              <input
                value={settings.social.twitter}
                onChange={e => setSettings(prev => prev ? { ...prev, social: { ...prev.social, twitter: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">Instagram</label>
              <input
                value={settings.social.instagram}
                onChange={e => setSettings(prev => prev ? { ...prev, social: { ...prev.social, instagram: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">Youtube</label>
              <input
                value={settings.social.youtube}
                onChange={e => setSettings(prev => prev ? { ...prev, social: { ...prev.social, youtube: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
          </div>
        </motion.div>

        {/* SEO */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="card-oasis p-6"
        >
          <h2 className="text-xl font-bold text-oasis-900 mb-6">SEO</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">العنوان</label>
              <input
                value={settings.seo.title}
                onChange={e => setSettings(prev => prev ? { ...prev, seo: { ...prev.seo, title: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">الوصف</label>
              <textarea
                rows={2}
                value={settings.seo.description}
                onChange={e => setSettings(prev => prev ? { ...prev, seo: { ...prev.seo, description: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-oasis-900 mb-1">الكلمات المفتاحية</label>
              <input
                value={settings.seo.keywords}
                onChange={e => setSettings(prev => prev ? { ...prev, seo: { ...prev.seo, keywords: e.target.value } } : prev)}
                className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
              />
            </div>
          </div>
        </motion.div>

        <button
          type="submit"
          disabled={saving}
          className="btn-primary gap-2 disabled:opacity-50"
        >
          <Save size={18} />
          {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
        </button>
      </form>
    </div>
  );
};

export default AdminSettingsPage;
