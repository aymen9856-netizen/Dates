import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, Truck, MapPin, Phone, User, Mail, FileText } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/utils/format';
import { setSEO } from '@/utils/seo';

const CheckoutPage: React.FC = () => {
  const { items, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    notes: '',
  });

  React.useEffect(() => {
    setSEO({
      title: 'إتمام الطلب - مزرعة الواحات',
      description: 'أكمل بياناتك لإتمام طلبك.',
    });
  }, []);

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  const shipping = totalPrice >= 200 ? 0 : 25;
  const finalTotal = totalPrice + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const orderData = {
        customerName: formData.name,
        customerPhone: formData.phone,
        customerEmail: formData.email,
        address: formData.address,
        city: formData.city,
        notes: formData.notes,
        items: items.map(item => ({
          productId: item.product.id,
          name: item.product.name,
          price: item.product.price,
          quantity: item.quantity,
          weight: item.product.weight,
          image: item.product.mainImage,
        })),
        subtotal: totalPrice,
        discount: 0,
        shipping,
        total: finalTotal,
      };

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
      });

      const data = await response.json();
      if (data.success) {
        clearCart();
        navigate(`/order-success/${data.data.id}`);
      } else {
        alert(data.message || 'حدث خطأ أثناء إنشاء الطلب');
      }
    } catch {
      alert('حدث خطأ في الاتصال');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        <h1 className="text-3xl font-bold text-oasis-900 mb-8">إتمام الطلب</h1>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <form onSubmit={handleSubmit} className="card-oasis p-8 space-y-6">
              <h2 className="text-xl font-bold text-oasis-900 mb-4 flex items-center gap-2">
                <User size={20} />
                بيانات العميل
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-2">الاسم الكامل *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    placeholder="محمد العتيبي"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-2">رقم الهاتف *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    placeholder="05XXXXXXXX"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                  placeholder="your@email.com"
                />
              </div>

              <h2 className="text-xl font-bold text-oasis-900 mb-4 flex items-center gap-2 pt-4 border-t border-sand-200">
                <MapPin size={20} />
                عنوان التوصيل
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-2">المدينة *</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={e => setFormData(prev => ({ ...prev, city: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    placeholder="الرياض"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-oasis-900 mb-2">العنوان التفصيلي *</label>
                  <textarea
                    required
                    rows={3}
                    value={formData.address}
                    onChange={e => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
                    placeholder="حي النخيل، شارع التمور، عمارة 123"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-oasis-900 mb-2">ملاحظات إضافية</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
                  placeholder="أي ملاحظات خاصة بالطلب..."
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full btn-primary disabled:opacity-50"
              >
                {loading ? 'جاري المعالجة...' : 'تأكيد الطلب'}
              </button>
            </form>
          </motion.div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="card-oasis p-8 sticky top-24">
              <h2 className="text-xl font-bold text-oasis-900 mb-6">ملخص الطلب</h2>

              <div className="space-y-4 mb-6">
                {items.map(item => (
                  <div key={item.product.id} className="flex gap-4">
                    <img
                      src={item.product.mainImage}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-lg object-cover bg-sand-100"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-oasis-900 text-sm">{item.product.name}</h4>
                      <p className="text-xs text-sand-500">{item.product.weight} × {item.quantity}</p>
                    </div>
                    <span className="font-semibold text-oasis-700">{formatPrice(item.product.price * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-sand-200 pt-4 space-y-3">
                <div className="flex justify-between text-sand-600">
                  <span>المجموع الفرعي</span>
                  <span>{formatPrice(totalPrice)}</span>
                </div>
                <div className="flex justify-between text-sand-600">
                  <span className="flex items-center gap-1">
                    <Truck size={14} />
                    الشحن
                  </span>
                  <span>{shipping === 0 ? 'مجاني' : formatPrice(shipping)}</span>
                </div>
              </div>

              <div className="border-t border-sand-200 mt-4 pt-4">
                <div className="flex justify-between text-xl font-bold text-oasis-900">
                  <span>الإجمالي</span>
                  <span>{formatPrice(finalTotal)}</span>
                </div>
              </div>

              <div className="mt-6 p-4 rounded-xl bg-green-50 border border-green-200">
                <div className="flex items-center gap-2 text-green-700 text-sm">
                  <Truck size={16} />
                  <span>الشحن مجاني للطلبات فوق 200 ريال</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
