import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Trash2, X, Percent, Tag } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import type { Coupon } from '@/types';

const AdminCouponsPage: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    code: '',
    type: 'percentage' as 'percentage' | 'fixed',
    value: 0,
    minOrder: 0,
    maxDiscount: 0,
    usageLimit: 100,
    startDate: '',
    endDate: '',
    isActive: true,
  });

  const fetchCoupons = () => {
    fetch('/api/coupons')
      .then(r => r.json())
      .then(data => {
        if (data.success) setCoupons(data.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      if (data.success) {
        setShowForm(false);
        setFormData({
          code: '', type: 'percentage', value: 0, minOrder: 0,
          maxDiscount: 0, usageLimit: 100, startDate: '', endDate: '', isActive: true,
        });
        fetchCoupons();
      }
    } catch {
      alert('حدث خطأ');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد؟')) return;
    try {
      const response = await fetch(`/api/coupons/${id}`, { method: 'DELETE' });
      if (response.ok) fetchCoupons();
    } catch {
      alert('حدث خطأ');
    }
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-oasis-900">الكوبونات</h1>
        <button onClick={() => setShowForm(true)} className="btn-primary gap-2">
          <Plus size={18} />
          إضافة كوبون
        </button>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {coupons.map((coupon, i) => (
            <motion.div
              key={coupon.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="card-oasis p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  coupon.type === 'percentage' ? 'bg-blue-50 text-blue-600' : 'bg-green-50 text-green-600'
                }`}>
                  {coupon.type === 'percentage' ? <Percent size={20} /> : <Tag size={20} />}
                </div>
                <button
                  onClick={() => handleDelete(coupon.id)}
                  className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <h3 className="text-2xl font-bold text-oasis-900 mb-1 font-mono">{coupon.code}</h3>
              <p className="text-sand-500 mb-4">
                {coupon.type === 'percentage' ? `خصم ${coupon.value}%` : `خصم ${coupon.value} ريال`}
              </p>

              <div className="space-y-2 text-sm text-sand-600">
                <p>الحد الأدنى: {coupon.minOrder} ريال</p>
                <p>الحد الأقصى: {coupon.maxDiscount} ريال</p>
                <p>الاستخدام: {coupon.usageCount} / {coupon.usageLimit}</p>
                <p>من: {new Date(coupon.startDate).toLocaleDateString('ar-SA')}</p>
                <p>إلى: {new Date(coupon.endDate).toLocaleDateString('ar-SA')}</p>
              </div>

              <div className="mt-4">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  coupon.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                }`}>
                  {coupon.isActive ? 'نشط' : 'غير نشط'}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add Coupon Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-lg p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-oasis-900">إضافة كوبون</h2>
                <button onClick={() => setShowForm(false)} className="p-2 hover:bg-sand-100 rounded-lg">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-1">الكود</label>
                  <input
                    required
                    value={formData.code}
                    onChange={e => setFormData(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                    className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 font-mono"
                    placeholder="OASIS20"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">النوع</label>
                    <select
                      value={formData.type}
                      onChange={e => setFormData(prev => ({ ...prev, type: e.target.value as 'percentage' | 'fixed' }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    >
                      <option value="percentage">نسبة مئوية (%)</option>
                      <option value="fixed">مبلغ ثابت (ريال)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">القيمة</label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={formData.value}
                      onChange={e => setFormData(prev => ({ ...prev, value: Number(e.target.value) }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الحد الأدنى للطلب</label>
                    <input
                      type="number"
                      min="0"
                      value={formData.minOrder}
                      onChange={e => setFormData(prev => ({ ...prev, minOrder: Number(e.target.value) }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الحد الأقصى للخصم</label>
                    <input
                      type="number"
                      min="0"
                      value={formData.maxDiscount}
                      onChange={e => setFormData(prev => ({ ...prev, maxDiscount: Number(e.target.value) }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-1">عدد الاستخدامات</label>
                  <input
                    type="number"
                    min="1"
                    value={formData.usageLimit}
                    onChange={e => setFormData(prev => ({ ...prev, usageLimit: Number(e.target.value) }))}
                    className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">تاريخ البدء</label>
                    <input
                      type="date"
                      required
                      value={formData.startDate}
                      onChange={e => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">تاريخ الانتهاء</label>
                    <input
                      type="date"
                      required
                      value={formData.endDate}
                      onChange={e => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 btn-primary">إضافة</button>
                  <button type="button" onClick={() => setShowForm(false)} className="px-6 py-3 rounded-lg border border-sand-200 hover:bg-sand-50">إلغاء</button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminCouponsPage;
