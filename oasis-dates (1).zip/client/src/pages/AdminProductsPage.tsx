import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Pencil, Trash2, Eye, EyeOff, X, Upload, ImageIcon } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { formatPrice } from '@/utils/format';
import type { Product } from '@/types';

const emptyProduct: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'views' | 'sales'> = {
  name: '',
  description: '',
  price: 0,
  oldPrice: null,
  weight: '1 كجم',
  category: 'سكري',
  type: 'فاخر',
  quality: 'ممتاز',
  country: 'المملكة العربية السعودية',
  region: 'القصيم',
  stock: 0,
  sku: '',
  barcode: '',
  keywords: '',
  status: 'active',
  images: [],
  mainImage: '',
  featured: false,
};

const AdminProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState(emptyProduct);
  const [selectedImages, setSelectedImages] = useState<FileList | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const fetchProducts = () => {
    fetch('/api/products/admin')
      .then(r => r.json())
      .then(data => {
        if (data.success) setProducts(data.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        data.append(key, String(value));
      }
    });

    if (selectedImages) {
      Array.from(selectedImages).forEach(file => {
        data.append('images', file);
      });
    }

    try {
      const url = editingProduct ? `/api/products/${editingProduct.id}` : '/api/products';
      const method = editingProduct ? 'PUT' : 'POST';

      const response = await fetch(url, { method, body: data });
      const result = await response.json();

      if (result.success) {
        setShowForm(false);
        setEditingProduct(null);
        setFormData(emptyProduct);
        setSelectedImages(null);
        fetchProducts();
      } else {
        alert(result.message || 'حدث خطأ');
      }
    } catch {
      alert('حدث خطأ في الاتصال');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
    try {
      const response = await fetch(`/api/products/${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) fetchProducts();
    } catch {
      alert('حدث خطأ أثناء الحذف');
    }
  };

  const toggleStatus = async (product: Product) => {
    const newStatus = product.status === 'active' ? 'hidden' : 'active';
    try {
      const response = await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await response.json();
      if (data.success) fetchProducts();
    } catch {
      alert('حدث خطأ');
    }
  };

  const startEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      oldPrice: product.oldPrice,
      weight: product.weight,
      category: product.category,
      type: product.type,
      quality: product.quality,
      country: product.country,
      region: product.region,
      stock: product.stock,
      sku: product.sku,
      barcode: product.barcode,
      keywords: product.keywords,
      status: product.status,
      images: product.images,
      mainImage: product.mainImage,
      featured: product.featured,
    });
    setShowForm(true);
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.sku.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <h1 className="text-3xl font-bold text-oasis-900">المنتجات</h1>
        <button
          onClick={() => {
            setEditingProduct(null);
            setFormData(emptyProduct);
            setShowForm(true);
          }}
          className="btn-primary gap-2"
        >
          <Plus size={18} />
          إضافة منتج
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-sand-400" />
        <input
          type="text"
          placeholder="البحث في المنتجات..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pr-12 pl-4 py-3 rounded-xl border border-sand-200 bg-white focus:outline-none focus:ring-2 focus:ring-oasis-500"
        />
      </div>

      {/* Products Table */}
      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="card-oasis overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-sand-50 border-b border-sand-200">
                <tr>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">المنتج</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">السعر</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">المخزون</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">الحالة</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-sand-700">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sand-100">
                {filteredProducts.map(product => (
                  <tr key={product.id} className="hover:bg-sand-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img 
                          src={product.mainImage} 
                          alt={product.name}
                          className="w-12 h-12 rounded-lg object-cover bg-sand-200"
                        />
                        <div>
                          <p className="font-semibold text-oasis-900">{product.name}</p>
                          <p className="text-xs text-sand-500">{product.sku}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-semibold">{formatPrice(product.price)}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        product.stock < 20 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                      }`}>
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => toggleStatus(product)}
                        className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                          product.status === 'active' 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {product.status === 'active' ? 'نشط' : 'مخفي'}
                      </button>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => startEdit(product)}
                          className="p-2 rounded-lg hover:bg-oasis-50 text-oasis-600 transition-colors"
                        >
                          <Pencil size={16} />
                        </button>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="p-2 rounded-lg hover:bg-red-50 text-red-500 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Product Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-sand-200 flex items-center justify-between">
                <h2 className="text-xl font-bold text-oasis-900">
                  {editingProduct ? 'تعديل منتج' : 'إضافة منتج'}
                </h2>
                <button onClick={() => setShowForm(false)} className="p-2 hover:bg-sand-100 rounded-lg">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الاسم *</label>
                    <input
                      required
                      value={formData.name}
                      onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">SKU *</label>
                    <input
                      required
                      value={formData.sku}
                      onChange={e => setFormData(prev => ({ ...prev, sku: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-1">الوصف</label>
                  <textarea
                    rows={3}
                    value={formData.description}
                    onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 resize-none"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">السعر *</label>
                    <input
                      type="number"
                      required
                      min="0"
                      step="0.01"
                      value={formData.price}
                      onChange={e => setFormData(prev => ({ ...prev, price: Number(e.target.value) }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">السعر قبل التخفيض</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.oldPrice || ''}
                      onChange={e => setFormData(prev => ({ ...prev, oldPrice: e.target.value ? Number(e.target.value) : null }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">المخزون *</label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={formData.stock}
                      onChange={e => setFormData(prev => ({ ...prev, stock: Number(e.target.value) }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">التصنيف</label>
                    <select
                      value={formData.category}
                      onChange={e => setFormData(prev => ({ ...prev, category: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    >
                      {['سكري', 'خلاص', 'برحي', 'صقعي', 'مجدول', 'مجهول'].map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">النوع</label>
                    <select
                      value={formData.type}
                      onChange={e => setFormData(prev => ({ ...prev, type: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    >
                      {['فاخر', 'مجروش', 'كبير', 'متوسط', 'رطب'].map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الجودة</label>
                    <select
                      value={formData.quality}
                      onChange={e => setFormData(prev => ({ ...prev, quality: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    >
                      {['ممتاز', 'فاخر', 'جيد جداً'].map(q => (
                        <option key={q} value={q}>{q}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الوزن</label>
                    <input
                      value={formData.weight}
                      onChange={e => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-oasis-900 mb-1">الباركود</label>
                    <input
                      value={formData.barcode}
                      onChange={e => setFormData(prev => ({ ...prev, barcode: e.target.value }))}
                      className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-1">الكلمات المفتاحية (SEO)</label>
                  <input
                    value={formData.keywords}
                    onChange={e => setFormData(prev => ({ ...prev, keywords: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500"
                    placeholder="تمر، سكري، فاخر..."
                  />
                </div>

                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.featured}
                      onChange={e => setFormData(prev => ({ ...prev, featured: e.target.checked }))}
                      className="w-4 h-4 rounded border-sand-300 text-oasis-600 focus:ring-oasis-500"
                    />
                    <span className="text-sm text-oasis-900">منتج مميز</span>
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-oasis-900 mb-1">الصور</label>
                  <div className="border-2 border-dashed border-sand-300 rounded-xl p-6 text-center hover:border-oasis-400 transition-colors">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={e => setSelectedImages(e.target.files)}
                      className="hidden"
                      id="product-images"
                    />
                    <label htmlFor="product-images" className="cursor-pointer">
                      <ImageIcon size={32} className="text-sand-400 mx-auto mb-2" />
                      <p className="text-sm text-sand-500">اضغط لرفع الصور</p>
                      {selectedImages && (
                        <p className="text-sm text-oasis-600 mt-2">{selectedImages.length} صورة محددة</p>
                      )}
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 btn-primary disabled:opacity-50"
                  >
                    {submitting ? 'جاري الحفظ...' : editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-6 py-3 rounded-lg border border-sand-200 hover:bg-sand-50 transition-colors"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminProductsPage;
