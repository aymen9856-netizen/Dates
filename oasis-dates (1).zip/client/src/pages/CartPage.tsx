import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft, Truck, Tag } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/utils/format';
import { setSEO } from '@/utils/seo';

const CartPage: React.FC = () => {
  const { items, removeItem, updateQuantity, totalPrice, clearCart } = useCart();
  const [couponCode, setCouponCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState(0);
  const navigate = useNavigate();

  React.useEffect(() => {
    setSEO({
      title: 'سلة المشتريات - مزرعة الواحات',
      description: 'راجع طلباتك و أكمل عملية الشراء.',
    });
  }, []);

  const shipping = totalPrice >= 200 ? 0 : 25;
  const finalTotal = totalPrice + shipping - couponDiscount;

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    try {
      const response = await fetch(`/api/coupons/validate?code=${couponCode}&total=${totalPrice}`);
      const data = await response.json();
      if (data.success && data.data.valid) {
        setCouponDiscount(data.data.discount);
      } else {
        alert(data.data?.message || 'الكوبون غير صالح');
      }
    } catch {
      alert('حدث خطأ أثناء التحقق من الكوبون');
    }
  };

  if (items.length === 0) {
    return (
      <div className="pt-24 pb-16 min-h-screen bg-sand-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag size={80} className="text-sand-300 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-oasis-900 mb-4">سلة المشتريات فارغة</h2>
          <p className="text-sand-500 mb-8">لم تقم بإضافة أي منتجات بعد</p>
          <Link to="/products" className="btn-primary">
            تصفح المنتجات
            <ArrowLeft size={20} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16 min-h-screen bg-sand-50">
      <div className="container-oasis">
        <h1 className="text-3xl font-bold text-oasis-900 mb-8">سلة المشتريات</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item, i) => (
              <motion.div
                key={item.product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="card-oasis p-6 flex gap-6"
              >
                <Link to={`/products/${item.product.id}`} className="shrink-0">
                  <img
                    src={item.product.mainImage}
                    alt={item.product.name}
                    className="w-24 h-24 rounded-xl object-cover bg-sand-100"
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/products/${item.product.id}`}>
                    <h3 className="font-bold text-oasis-900 mb-1 hover:text-oasis-600 transition-colors truncate">
                      {item.product.name}
                    </h3>
                  </Link>
                  <p className="text-sm text-sand-500 mb-3">{item.product.weight}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center border border-sand-200 rounded-lg overflow-hidden">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-2 hover:bg-sand-50 transition-colors"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="w-10 text-center text-sm font-semibold">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-2 hover:bg-sand-50 transition-colors"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold text-oasis-700">{formatPrice(item.product.price * item.quantity)}</span>
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            <button
              onClick={clearCart}
              className="text-red-500 hover:text-red-600 text-sm flex items-center gap-1"
            >
              <Trash2 size={14} />
              إفراغ السلة
            </button>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="card-oasis p-6 sticky top-24">
              <h2 className="text-xl font-bold text-oasis-900 mb-6">ملخص الطلب</h2>

              {/* Coupon */}
              <div className="mb-6">
                <label className="text-sm font-semibold text-oasis-900 mb-2 block">كوبون الخصم</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    placeholder="أدخل الكود"
                    className="flex-1 px-4 py-2 rounded-lg border border-sand-200 focus:outline-none focus:ring-2 focus:ring-oasis-500 text-sm"
                  />
                  <button
                    onClick={applyCoupon}
                    className="px-4 py-2 rounded-lg bg-oasis-100 text-oasis-700 font-semibold hover:bg-oasis-200 transition-colors text-sm"
                  >
                    <Tag size={16} />
                  </button>
                </div>
              </div>

              <div className="space-y-3 mb-6 pb-6 border-b border-sand-200">
                <div className="flex justify-between text-sand-600">
                  <span>المجموع الفرعي</span>
                  <span>{formatPrice(totalPrice)}</span>
                </div>
                {couponDiscount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>خصم الكوبون</span>
                    <span>-{formatPrice(couponDiscount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sand-600">
                  <span className="flex items-center gap-1">
                    <Truck size={14} />
                    الشحن
                  </span>
                  <span>{shipping === 0 ? 'مجاني' : formatPrice(shipping)}</span>
                </div>
              </div>

              <div className="flex justify-between text-xl font-bold text-oasis-900 mb-6">
                <span>الإجمالي</span>
                <span>{formatPrice(finalTotal)}</span>
              </div>

              <button
                onClick={() => navigate('/checkout')}
                className="w-full btn-primary"
              >
                إتمام الطلب
              </button>

              {shipping > 0 && (
                <p className="text-center text-sm text-sand-500 mt-4">
                  أضف منتجات بقيمة {formatPrice(200 - totalPrice)} للحصول على شحن مجاني
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
