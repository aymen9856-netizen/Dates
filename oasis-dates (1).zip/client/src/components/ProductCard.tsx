import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Eye, Star } from 'lucide-react';
import type { Product } from '@/types';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/utils/format';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = memo(({ product }) => {
  const { addItem } = useCart();

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  return (
    <div className="group card-oasis">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-sand-100">
        <img
          src={product.mainImage}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/placeholder-product.jpg';
          }}
        />

        {/* Discount badge */}
        {discount > 0 && (
          <div className="absolute top-3 left-3 bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-full">
            خصم {discount}%
          </div>
        )}

        {/* Overlay actions */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
          <Link
            to={`/products/${product.id}`}
            className="w-12 h-12 rounded-full bg-white flex items-center justify-center hover:bg-oasis-100 transition-colors"
          >
            <Eye size={20} className="text-oasis-800" />
          </Link>
          <button
            onClick={() => addItem(product)}
            className="w-12 h-12 rounded-full bg-oasis-600 flex items-center justify-center hover:bg-oasis-700 transition-colors"
          >
            <ShoppingCart size={20} className="text-white" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-center gap-1 mb-2">
          <Star size={14} className="text-oasis-400 fill-oasis-400" />
          <span className="text-sm text-sand-500">{product.quality}</span>
          <span className="text-sand-300">|</span>
          <span className="text-sm text-sand-500">{product.weight}</span>
        </div>

        <Link to={`/products/${product.id}`}>
          <h3 className="font-bold text-oasis-900 mb-2 group-hover:text-oasis-600 transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-sand-500 mb-3 line-clamp-2">{product.description}</p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-oasis-700 text-lg">{formatPrice(product.price)}</span>
            {product.oldPrice && (
              <span className="text-sm text-sand-400 line-through">{formatPrice(product.oldPrice)}</span>
            )}
          </div>
          <button
            onClick={() => addItem(product)}
            className="p-2 rounded-lg bg-oasis-50 text-oasis-600 hover:bg-oasis-100 transition-colors"
          >
            <ShoppingCart size={18} />
          </button>
        </div>
      </div>
    </div>
  );
});

ProductCard.displayName = 'ProductCard';
