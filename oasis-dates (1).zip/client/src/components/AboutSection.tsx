import React from 'react';
import { motion } from 'framer-motion';
import { Leaf, Droplets, Sun, Shield } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const features = [
    {
      icon: <Sun size={32} />,
      title: 'مناخ مثالي',
      description: 'تقع مزارعنا في منطقة القصيم حيث المناخ الصحراوي المثالي لنمو أفضل أنواع النخيل.',
    },
    {
      icon: <Droplets size={32} />,
      title: 'ري طبيعي',
      description: 'نستخدم أنظمة ري حديثة مع المياه الجوفية النقية لضمان جودة التمور.',
    },
    {
      icon: <Leaf size={32} />,
      title: 'زراعة عضوية',
      description: 'نعتمد على الزراعة العضوية بدون مبيدات كيميائية لضمان صحة المنتج.',
    },
    {
      icon: <Shield size={32} />,
      title: 'جودة مضمونة',
      description: 'كل دفعة تمر بفحص جودة صارم للتأكد من مطابقتها لأعلى المعايير.',
    },
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container-oasis">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-oasis-600 font-semibold mb-4 block">من نحن</span>
            <h2 className="section-title">مزرعة الواحات</h2>
            <p className="text-sand-600 leading-relaxed mb-6 text-lg">
              منذ أكثر من 15 عاماً، نزرع وننتج أجود أنواع التمور في منطقة القصيم. 
              نؤمن بأن التمر ليس مجرد منتج، بل هو تراث وهوية وثقافة عربية أصيلة.
            </p>
            <p className="text-sand-600 leading-relaxed mb-8">
              نحرص على كل تفصيل بدءاً من اختيار النخلة وصولاً إلى تغليف التمر وتسليمه إليكم. 
              هدفنا الوحيد هو تقديم تجربة استثنائية تعكس فخرنا بهذا المنتج الوطني.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {features.map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-4 rounded-xl bg-sand-50 border border-sand-100"
                >
                  <div className="text-oasis-600 mb-2">{f.icon}</div>
                  <h4 className="font-bold text-oasis-900 mb-1">{f.title}</h4>
                  <p className="text-sm text-sand-500">{f.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative">
              <div className="absolute -inset-4 bg-oasis-100 rounded-3xl transform rotate-3" />
              <img
                src="/uploads/about-farm.jpg"
                alt="مزرعة الواحات"
                className="relative rounded-3xl shadow-xl w-full aspect-[4/3] object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  const parent = (e.target as HTMLImageElement).parentElement;
                  if (parent) {
                    parent.innerHTML = `<div class="w-full aspect-[4/3] bg-oasis-100 rounded-3xl flex items-center justify-center"><span class="text-oasis-600 text-8xl">🌴</span></div>`;
                  }
                }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
