import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Truck, ShieldCheck, Clock, Award, Sparkles } from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Heart size={32} />,
      title: 'جودة فاخرة',
      desc: 'نختار أفضل التمور يدوياً لضمان الجودة المثالية',
    },
    {
      icon: <Truck size={32} />,
      title: 'شحن سريع',
      desc: 'نوصل طلباتكم في أسرع وقت ممكن لجميع المناطق',
    },
    {
      icon: <ShieldCheck size={32} />,
      title: 'ضمان الجودة',
      desc: 'نضمن جودة منتجاتنا أو استرداد كامل المبلغ',
    },
    {
      icon: <Clock size={32} />,
      title: 'طازج دائماً',
      desc: 'نخزن التمور في ظروف مثالية للحفاظ على الطعم',
    },
    {
      icon: <Award size={32} />,
      title: 'معتمد دولياً',
      desc: 'حاصلين على شهادات جودة دولية معتمدة',
    },
    {
      icon: <Sparkles size={32} />,
      title: 'تغليف فاخر',
      desc: 'تغليف أنيق مناسب للهدايا والمناسبات الخاصة',
    },
  ];

  return (
    <section className="py-24 bg-sand-50">
      <div className="container-oasis">
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">لماذا نحن</span>
          <h2 className="section-title">ما يميز مزرعة الواحات</h2>
          <p className="section-subtitle">
            نلتزم بأعلى معايير الجودة في كل مرحلة من مراحل الإنتاج والتوصيل
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card-oasis p-8 text-center group hover:shadow-lg transition-all duration-300"
            >
              <div className="w-16 h-16 rounded-2xl bg-oasis-50 flex items-center justify-center text-oasis-600 mx-auto mb-6 group-hover:bg-oasis-600 group-hover:text-white transition-colors duration-300">
                {f.icon}
              </div>
              <h3 className="font-bold text-xl text-oasis-900 mb-3">{f.title}</h3>
              <p className="text-sand-500 leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
