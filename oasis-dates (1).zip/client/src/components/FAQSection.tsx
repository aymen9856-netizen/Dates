import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'ما هي أنواع التمور المتوفرة لديكم؟',
      a: 'نوفر مجموعة واسعة من التمور السعودية الفاخرة تشمل: السكري، الخلاص، البرحي، الصقعي، المجدول، المجهول، والرطب. كل نوع يتميز بطعم وملمس خاص.',
    },
    {
      q: 'كم يستغرق توصيل الطلبات؟',
      a: 'نقوم بالتوصيل خلال 1-3 أيام عمل داخل المدن الرئيسية، و3-5 أيام للمناطق الأخرى داخل المملكة. للطلبات الدولية يستغرق 7-14 يوماً.',
    },
    {
      q: 'هل يمكنني إرجاع المنتج؟',
      a: 'نعم، يمكنك إرجاع المنتج خلال 7 أيام من استلامه إذا كان غير مطابق للمواصفات أو به عيب مصنعي. نضمن استرداد كامل المبلغ.',
    },
    {
      q: 'هل التمور عضوية؟',
      a: 'نعم، نستخدم الزراعة العضوية بدون مبيدات كيميائية. نعتمد على الأساليب الطبيعية في العناية بالنخيل والحصاد.',
    },
    {
      q: 'هل تقدمون خصومات للطلبات بالجملة؟',
      a: 'نعم، نقدم خصومات خاصة للطلبات بالجملة. تواصل معنا عبر واتساب أو نموذج الطلب بالجملة للحصول على عرض سعر مخصص.',
    },
    {
      q: 'كيف أحفظ التمور بعد الشراء؟',
      a: 'يُفضل حفظ التمور في مكان بارد وجاف بعيداً عن أشعة الشمس المباشرة. يمكن تخزينها في الثلاجة لمدة تصل إلى 6 أشهر.',
    },
  ];

  return (
    <section className="py-24 bg-sand-50">
      <div className="container-oasis max-w-3xl">
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">الأسئلة الشائعة</span>
          <h2 className="section-title">كل ما تريد معرفته</h2>
          <p className="section-subtitle">
            إليكم إجابات على أكثر الأسئلة شيوعاً
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-white rounded-xl border border-sand-200 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-right hover:bg-sand-50 transition-colors"
              >
                <span className="font-semibold text-oasis-900">{faq.q}</span>
                <ChevronDown
                  size={20}
                  className={`text-oasis-500 transition-transform duration-300 shrink-0 ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 text-sand-600 leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
