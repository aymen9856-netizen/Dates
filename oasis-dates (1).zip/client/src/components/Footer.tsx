import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Youtube, Twitter, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-oasis-950 text-sand-200">
      {/* Main footer */}
      <div className="container-oasis py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-oasis-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">و</span>
              </div>
              <div>
                <h3 className="font-bold text-xl text-white">مزرعة الواحات</h3>
                <p className="text-xs text-sand-400">متجر التمور الفاخر</p>
              </div>
            </div>
            <p className="text-sand-400 leading-relaxed">
              نقدم لكم أجود أنواع التمور السعودية الفاخرة من مزارعنا في منطقة القصيم. 
              التزامنا بالجودة يبدأ من النخلة ويستمر حتى يصل إليكم.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-full bg-oasis-900 flex items-center justify-center hover:bg-oasis-700 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-oasis-900 flex items-center justify-center hover:bg-oasis-700 transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-oasis-900 flex items-center justify-center hover:bg-oasis-700 transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-oasis-900 flex items-center justify-center hover:bg-oasis-700 transition-colors">
                <Youtube size={18} />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-bold text-white mb-6">روابط سريعة</h4>
            <ul className="space-y-3">
              {[
                { to: '/', label: 'الرئيسية' },
                { to: '/products', label: 'المنتجات' },
                { to: '/about', label: 'عن المزرعة' },
                { to: '/packaging', label: 'طرق التعبئة' },
                { to: '/contact', label: 'تواصل معنا' },
              ].map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sand-400 hover:text-oasis-400 transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-bold text-white mb-6">أنواع التمور</h4>
            <ul className="space-y-3">
              {['سكري', 'خلاص', 'برحي', 'صقعي', 'مجدول', 'مجهول'].map(cat => (
                <li key={cat}>
                  <Link to={`/products?category=${cat}`} className="text-sand-400 hover:text-oasis-400 transition-colors">
                    تمر {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-6">تواصل معنا</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={20} className="text-oasis-500 mt-0.5 shrink-0" />
                <span className="text-sand-400">القصيم، المملكة العربية السعودية</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={20} className="text-oasis-500 shrink-0" />
                <a href="tel:+966551234567" className="text-sand-400 hover:text-oasis-400 transition-colors">
                  +966 55 123 4567
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={20} className="text-oasis-500 shrink-0" />
                <a href="mailto:info@oasis-dates.com" className="text-sand-400 hover:text-oasis-400 transition-colors">
                  info@oasis-dates.com
                </a>
              </li>
            </ul>

            {/* WhatsApp button */}
            <a
              href="https://wa.me/966551234567"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              تواصل عبر واتساب
            </a>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-oasis-900">
        <div className="container-oasis py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sand-500 text-sm">
            © 2024 مزرعة الواحات. جميع الحقوق محفوظة.
          </p>
          <p className="text-sand-500 text-sm flex items-center gap-1">
            صنع بـ <Heart size={14} className="text-red-500 fill-red-500" /> في المملكة العربية السعودية
          </p>
        </div>
      </div>
    </footer>
  );
};
