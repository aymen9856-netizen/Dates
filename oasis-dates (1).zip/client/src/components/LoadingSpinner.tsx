import React from 'react';

export const LoadingSpinner: React.FC<{ size?: number; className?: string }> = ({ 
  size = 40, 
  className = '' 
}) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <div
        className="border-4 border-oasis-200 border-t-oasis-600 rounded-full animate-spin"
        style={{ width: size, height: size }}
      />
    </div>
  );
};
