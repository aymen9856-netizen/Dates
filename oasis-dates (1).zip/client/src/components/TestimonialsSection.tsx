import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      name: 'أحمد العتيبي',
      location: 'الرياض',
      rating: 5,
      text: 'أفضل تمور جربتها في حياتي! الجودة ممتازة والطعم لا يُوصف. سأكون عميلاً دائماً.',
      avatar: 'أ',
    },
    {
      name: 'سارة القحطاني',
      location: 'جدة',
      rating: 5,
      text: 'طلبت للمناسبة العائلية والجميع أعجب بالجودة والتغليف الراقي. شكراً مزرعة الواحات!',
      avatar: 'س',
    },
    {
      name: 'محمد الدوسري',
      location: 'الدمام',
      rating: 5,
      text: 'الشحن سريع والتمور وصلت طازجة. التمر السكري فاخر بمعنى الكلمة. أنصح الجميع بالتجربة.',
      avatar: 'م',
    },
    {
      name: 'نورة الشمري',
      location: 'حائل',
      rating: 5,
      text: 'أرسلت هدية لعائلتي في الخارج ووصلت بأمان. التغليف فاخر والجودة ممتازة.',
      avatar: 'ن',
    },
  ];

  return (
    <section className="py-24 bg-oasis-950 text-white">
      <div className="container-oasis">
        <div className="text-center mb-16">
          <span className="text-oasis-400 font-semibold mb-4 block">آراء العملاء</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">ما يقوله عملاؤنا</h2>
          <p className="text-sand-400 max-w-2xl mx-auto">
            نفخر بثقة آلاف العملاء الذين يختارون مزرعة الواحات
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-oasis-900/50 rounded-2xl p-6 border border-oasis-800"
            >
              <Quote size={24} className="text-oasis-500 mb-4" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} size={16} className="text-oasis-400 fill-oasis-400" />
                ))}
              </div>
              <p className="text-sand-300 leading-relaxed mb-6 text-sm">{t.text}</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-oasis-700 flex items-center justify-center font-bold text-oasis-300">
                  {t.avatar}
                </div>
                <div>
                  <p className="font-semibold text-sm">{t.name}</p>
                  <p className="text-xs text-sand-500">{t.location}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
