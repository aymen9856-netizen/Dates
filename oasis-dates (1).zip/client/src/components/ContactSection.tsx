import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

export const ContactSection: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container-oasis">
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">تواصل معنا</span>
          <h2 className="section-title">نحن هنا لمساعدتك</h2>
          <p className="section-subtitle">
            لا تتردد في التواصل معنا لأي استفسار أو طلب
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: <Phone size={28} />,
              title: 'اتصل بنا',
              info: '+966 55 123 4567',
              link: 'tel:+966551234567',
            },
            {
              icon: <Mail size={28} />,
              title: 'البريد الإلكتروني',
              info: 'info@oasis-dates.com',
              link: 'mailto:info@oasis-dates.com',
            },
            {
              icon: <MapPin size={28} />,
              title: 'الموقع',
              info: 'القصيم، المملكة العربية السعودية',
              link: '#',
            },
            {
              icon: <Clock size={28} />,
              title: 'ساعات العمل',
              info: 'السبت - الخميس: 8 ص - 10 م',
              link: '#',
            },
          ].map((item, i) => (
            <motion.a
              key={item.title}
              href={item.link}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card-oasis p-8 text-center group hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-xl bg-oasis-50 flex items-center justify-center text-oasis-600 mx-auto mb-4 group-hover:bg-oasis-600 group-hover:text-white transition-colors duration-300">
                {item.icon}
              </div>
              <h3 className="font-bold text-oasis-900 mb-2">{item.title}</h3>
              <p className="text-sand-500 text-sm">{item.info}</p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
};
