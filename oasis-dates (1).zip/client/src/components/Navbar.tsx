import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu, X, Phone, Search, User, LogIn } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useAdmin } from '@/contexts/AdminContext';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { totalItems } = useCart();
  const { isAuthenticated } = useAdmin();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'الرئيسية' },
    { to: '/products', label: 'المنتجات' },
    { to: '/about', label: 'عن المزرعة' },
    { to: '/packaging', label: 'العبئة' },
    { to: '/contact', label: 'تواصل معنا' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      {/* Top bar */}
      <div className={`transition-all duration-300 overflow-hidden ${isScrolled ? 'h-0' : 'h-10'}`}>
        <div className="bg-oasis-900 text-white">
          <div className="container-oasis flex items-center justify-between h-10 text-sm">
            <div className="flex items-center gap-4">
              <a href="tel:+966551234567" className="flex items-center gap-1 hover:text-oasis-300 transition-colors">
                <Phone size={14} />
                <span>+966 55 123 4567</span>
              </a>
            </div>
            <div className="flex items-center gap-4">
              <span>شحن مجاني للطلبات فوق 200 ريال</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div className="container-oasis">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-oasis-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">و</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="font-bold text-xl text-oasis-900">مزرعة الواحات</h1>
              <p className="text-xs text-sand-500 -mt-1">متجر التمور الفاخر</p>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`font-medium transition-colors hover:text-oasis-600 ${
                  location.pathname === link.to ? 'text-oasis-600' : 'text-sand-700'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Link to="/products" className="p-2 rounded-lg hover:bg-sand-100 transition-colors">
              <Search size={20} className="text-sand-700" />
            </Link>
            <Link to="/cart" className="relative p-2 rounded-lg hover:bg-sand-100 transition-colors">
              <ShoppingCart size={20} className="text-sand-700" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-oasis-600 text-white text-xs rounded-full flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </Link>
            {isAuthenticated ? (
              <Link to="/admin" className="p-2 rounded-lg hover:bg-sand-100 transition-colors">
                <User size={20} className="text-oasis-600" />
              </Link>
            ) : (
              <Link to="/admin/login" className="p-2 rounded-lg hover:bg-sand-100 transition-colors">
                <LogIn size={20} className="text-sand-700" />
              </Link>
            )}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-sand-100 transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`lg:hidden overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
        <div className="bg-white border-t border-sand-200 shadow-lg">
          <div className="container-oasis py-4 space-y-2">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`block py-2 px-4 rounded-lg font-medium transition-colors ${
                  location.pathname === link.to ? 'bg-oasis-50 text-oasis-700' : 'text-sand-700 hover:bg-sand-50'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};
