import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Leaf, Award, Truck } from 'lucide-react';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-oasis-950 via-oasis-900 to-oasis-800" />
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d4a853' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Content */}
      <div className="container-oasis relative z-10 py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-oasis-800/50 border border-oasis-600/30 text-oasis-300 text-sm mb-6">
              <Leaf size={16} />
              <span>تمور طبيعية 100% من مزارعنا</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              أجود أنواع
              <span className="text-oasis-400 block mt-2">التمور السعودية</span>
            </h1>

            <p className="text-lg text-sand-300 mb-8 leading-relaxed max-w-lg">
              من مزارعنا في منطقة القصيم، نقدم لكم أفضل أنواع التمور الفاخرة. 
              سكري، خلاص، صقعي، مجدول وغيرها بأعلى معايير الجودة.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link to="/products" className="btn-primary text-lg px-8">
                تصفح المنتجات
                <ArrowLeft size={20} />
              </Link>
              <Link to="/about" className="btn-outline text-white border-white/30 hover:bg-white/10">
                تعرف علينا
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-white/10">
              {[
                { value: '15+', label: 'سنوات خبرة' },
                { value: '50K+', label: 'عميل سعيد' },
                { value: '100%', label: 'جودة مضمونة' },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                >
                  <div className="text-2xl md:text-3xl font-bold text-oasis-400">{stat.value}</div>
                  <div className="text-sm text-sand-400 mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Hero image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="relative">
              <div className="absolute -inset-4 bg-oasis-500/20 rounded-3xl blur-2xl" />
              <img
                src="/uploads/hero-dates.jpg"
                alt="تمور فاخرة من مزرعة الواحات"
                className="relative rounded-3xl shadow-2xl w-full aspect-[4/5] object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  const parent = (e.target as HTMLImageElement).parentElement;
                  if (parent) {
                    parent.innerHTML = `<div class="w-full aspect-[4/5] bg-oasis-800 rounded-3xl flex items-center justify-center"><span class="text-oasis-400 text-6xl">🌴</span></div>`;
                  }
                }}
              />

              {/* Floating badges */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -right-4 top-1/4 bg-white rounded-2xl p-4 shadow-xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <Leaf size={20} className="text-green-600" />
                  </div>
                  <div>
                    <p className="font-bold text-oasis-900">عضوي 100%</p>
                    <p className="text-sm text-sand-500">بدون إضافات</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                className="absolute -left-4 bottom-1/4 bg-white rounded-2xl p-4 shadow-xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-oasis-100 flex items-center justify-center">
                    <Award size={20} className="text-oasis-600" />
                  </div>
                  <div>
                    <p className="font-bold text-oasis-900">جودة ممتازة</p>
                    <p className="text-sm text-sand-500">معتمدة دولياً</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#faf8f5"/>
        </svg>
      </div>
    </section>
  );
};
