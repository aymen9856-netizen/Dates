import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, Tag, Settings, 
  LogOut, Menu, X, ChevronLeft, BarChart3, FileText 
} from 'lucide-react';
import { useAdmin } from '@/contexts/AdminContext';

export const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAdmin();

  const menuItems = [
    { to: '/admin', icon: <LayoutDashboard size={20} />, label: 'الرئيسية' },
    { to: '/admin/products', icon: <Package size={20} />, label: 'المنتجات' },
    { to: '/admin/orders', icon: <ShoppingCart size={20} />, label: 'الطلبات' },
    { to: '/admin/customers', icon: <Users size={20} />, label: 'العملاء' },
    { to: '/admin/coupons', icon: <Tag size={20} />, label: 'الكوبونات' },
    { to: '/admin/settings', icon: <Settings size={20} />, label: 'الإعدادات' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-sand-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 right-0 h-screen w-72 bg-oasis-950 text-white z-50 transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      }`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <Link to="/admin" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-oasis-600 flex items-center justify-center">
                <span className="font-bold text-lg">و</span>
              </div>
              <div>
                <h2 className="font-bold">لوحة الإدارة</h2>
                <p className="text-xs text-sand-400">مزرعة الواحات</p>
              </div>
            </Link>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
              <X size={24} />
            </button>
          </div>

          <nav className="space-y-1">
            {menuItems.map(item => (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                  location.pathname === item.to 
                    ? 'bg-oasis-600 text-white' 
                    : 'text-sand-300 hover:bg-oasis-900 hover:text-white'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>

          <div className="mt-auto pt-8 border-t border-oasis-800">
            <Link 
              to="/" 
              className="flex items-center gap-3 px-4 py-3 text-sand-300 hover:text-white transition-colors mb-2"
            >
              <ChevronLeft size={20} />
              <span>العودة للموقع</span>
            </Link>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 transition-colors"
            >
              <LogOut size={20} />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0">
        {/* Mobile header */}
        <div className="lg:hidden bg-white border-b border-sand-200 p-4 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(true)}>
            <Menu size={24} className="text-oasis-900" />
          </button>
          <span className="font-bold text-oasis-900">لوحة الإدارة</span>
          <div className="w-8" />
        </div>
        <main className="min-h-screen">
          {children}
        </main>
      </div>
    </div>
  );
};
