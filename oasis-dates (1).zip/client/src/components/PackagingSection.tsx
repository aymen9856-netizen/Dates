import React from 'react';
import { motion } from 'framer-motion';
import { Search, Droplets, Package, Truck } from 'lucide-react';

export const PackagingSection: React.FC = () => {
  const steps = [
    {
      icon: <Search size={28} />,
      title: 'الفرز والتدقيق',
      desc: 'نفرز التمور يدوياً ونختار فقط الأفضل حسب الحجم والجودة والنضج المثالي.',
      color: 'bg-blue-50 text-blue-600',
    },
    {
      icon: <Droplets size={28} />,
      title: 'التنظيف والتعقيم',
      desc: 'نغسل التمور بمياه نقية ونعقمها بأحدث التقنيات لضمان النظافة والسلامة.',
      color: 'bg-cyan-50 text-cyan-600',
    },
    {
      icon: <Package size={28} />,
      title: 'التعبئة الفاخرة',
      desc: 'نعبئ التمور في عبوات محكمة الإغلاق تحافظ على الطراوة والنكهة الطبيعية.',
      color: 'bg-oasis-50 text-oasis-600',
    },
    {
      icon: <Truck size={28} />,
      title: 'الشحن والتوصيل',
      desc: 'نغلف الطلبات بعناية ونوصلها إليكم في أسرع وقت مع الحفاظ على الجودة.',
      color: 'bg-green-50 text-green-600',
    },
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container-oasis">
        <div className="text-center mb-16">
          <span className="text-oasis-600 font-semibold mb-4 block">مراحل الإنتاج</span>
          <h2 className="section-title">من النخلة إلى منزلكم</h2>
          <p className="section-subtitle">
            نتابع كل مرحلة بعناية فائقة لضمان وصول أفضل جودة إليكم
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative"
            >
              <div className="card-oasis p-6 text-center h-full">
                <div className={`w-14 h-14 rounded-xl ${step.color} flex items-center justify-center mx-auto mb-4`}>
                  {step.icon}
                </div>
                <div className="text-3xl font-bold text-sand-200 mb-2">0{i + 1}</div>
                <h3 className="font-bold text-lg text-oasis-900 mb-3">{step.title}</h3>
                <p className="text-sand-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -left-4 w-8 h-0.5 bg-sand-200" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
