import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

interface AdminContextType {
  isAuthenticated: boolean;
  login: (password: string) => Promise<boolean>;
  logout: () => void;
  sessionExpiry: Date | null;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

const SESSION_KEY = 'admin_session';
const IDLE_TIMEOUT = 30 * 60 * 1000; // 30 minutes

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sessionExpiry, setSessionExpiry] = useState<Date | null>(null);

  useEffect(() => {
    const checkSession = () => {
      const session = localStorage.getItem(SESSION_KEY);
      if (session) {
        try {
          const { expires } = JSON.parse(session);
          if (new Date(expires) > new Date()) {
            setIsAuthenticated(true);
            setSessionExpiry(new Date(expires));
          } else {
            localStorage.removeItem(SESSION_KEY);
          }
        } catch {
          localStorage.removeItem(SESSION_KEY);
        }
      }
    };
    checkSession();
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    let idleTimer: ReturnType<typeof setTimeout>;

    const resetTimer = () => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        logout();
      }, IDLE_TIMEOUT);
    };

    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(e => document.addEventListener(e, resetTimer));
    resetTimer();

    return () => {
      clearTimeout(idleTimer);
      events.forEach(e => document.removeEventListener(e, resetTimer));
    };
  }, [isAuthenticated]);

  const login = useCallback(async (password: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await response.json();
      if (data.success) {
        setIsAuthenticated(true);
        const expiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
        setSessionExpiry(expiry);
        localStorage.setItem(SESSION_KEY, JSON.stringify({ token: data.data.token, expires: expiry.toISOString() }));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, []);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
    setSessionExpiry(null);
    localStorage.removeItem(SESSION_KEY);
  }, []);

  return (
    <AdminContext.Provider value={{ isAuthenticated, login, logout, sessionExpiry }}>
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) throw new Error('useAdmin must be used within AdminProvider');
  return context;
};
