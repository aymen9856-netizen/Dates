const API_BASE = import.meta.env.VITE_API_URL || '';

async function fetchApi<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Unknown error' }));
    throw new Error(error.message || `HTTP ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export const api = {
  products: {
    getAll: () => fetchApi('/api/products'),
    getById: (id: string) => fetchApi(`/api/products/${id}`),
    getFeatured: () => fetchApi('/api/products/featured'),
    getCategories: () => fetchApi('/api/products/categories'),
    search: (query: string) => fetchApi(`/api/products/search?q=${encodeURIComponent(query)}`),
    create: (data: FormData) => fetch('/api/products', { method: 'POST', body: data }).then(r => r.json()),
    update: (id: string, data: FormData) => fetch(`/api/products/${id}`, { method: 'PUT', body: data }).then(r => r.json()),
    delete: (id: string) => fetchApi(`/api/products/${id}`, { method: 'DELETE' }),
  },
  orders: {
    getAll: () => fetchApi('/api/orders'),
    getById: (id: string) => fetchApi(`/api/orders/${id}`),
    create: (data: unknown) => fetchApi('/api/orders', { method: 'POST', body: JSON.stringify(data) }),
    updateStatus: (id: string, status: string) => fetchApi(`/api/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    delete: (id: string) => fetchApi(`/api/orders/${id}`, { method: 'DELETE' }),
  },
  customers: {
    getAll: () => fetchApi('/api/customers'),
    getById: (id: string) => fetchApi(`/api/customers/${id}`),
    create: (data: unknown) => fetchApi('/api/customers', { method: 'POST', body: JSON.stringify(data) }),
  },
  coupons: {
    getAll: () => fetchApi('/api/coupons'),
    validate: (code: string, total: number) => fetchApi(`/api/coupons/validate?code=${code}&total=${total}`),
    create: (data: unknown) => fetchApi('/api/coupons', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: unknown) => fetchApi(`/api/coupons/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string) => fetchApi(`/api/coupons/${id}`, { method: 'DELETE' }),
  },
  settings: {
    get: () => fetchApi('/api/settings'),
    update: (data: unknown) => fetchApi('/api/settings', { method: 'PUT', body: JSON.stringify(data) }),
  },
  auth: {
    login: (password: string) => fetchApi('/api/auth/login', { method: 'POST', body: JSON.stringify({ password }) }),
    logout: () => fetchApi('/api/auth/logout', { method: 'POST' }),
    check: () => fetchApi('/api/auth/check'),
  },
  dashboard: {
    stats: () => fetchApi('/api/dashboard/stats'),
    recentOrders: () => fetchApi('/api/dashboard/recent-orders'),
    topProducts: () => fetchApi('/api/dashboard/top-products'),
  },
};
