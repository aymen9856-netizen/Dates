interface SEOMeta {
  title: string;
  description: string;
  keywords?: string;
  ogImage?: string;
  canonical?: string;
  noIndex?: boolean;
}

export const setSEO = (meta: SEOMeta) => {
  document.title = meta.title;

  const setMeta = (name: string, content: string) => {
    let element = document.querySelector(`meta[name="${name}"]`);
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute('name', name);
      document.head.appendChild(element);
    }
    element.setAttribute('content', content);
  };

  const setProperty = (property: string, content: string) => {
    let element = document.querySelector(`meta[property="${property}"]`);
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute('property', property);
      document.head.appendChild(element);
    }
    element.setAttribute('content', content);
  };

  setMeta('description', meta.description);
  if (meta.keywords) setMeta('keywords', meta.keywords);

  setProperty('og:title', meta.title);
  setProperty('og:description', meta.description);
  setProperty('og:type', 'website');
  if (meta.ogImage) setProperty('og:image', meta.ogImage);

  setMeta('twitter:title', meta.title);
  setMeta('twitter:description', meta.description);
  if (meta.ogImage) setMeta('twitter:image', meta.ogImage);

  if (meta.canonical) {
    let link = document.querySelector('link[rel="canonical"]');
    if (!link) {
      link = document.createElement('link');
      link.setAttribute('rel', 'canonical');
      document.head.appendChild(link);
    }
    link.setAttribute('href', meta.canonical);
  }

  if (meta.noIndex) {
    setMeta('robots', 'noindex, nofollow');
  }
};
