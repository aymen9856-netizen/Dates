import { useState, useEffect } from 'react';
import type { Order } from '@/types';

export function useOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/orders')
      .then(r => r.json())
      .then(data => {
        if (data.success) setOrders(data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  return { orders, loading, refetch: () => window.location.reload() };
}
