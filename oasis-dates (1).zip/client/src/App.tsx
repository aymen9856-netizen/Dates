import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { CartProvider } from '@/contexts/CartContext';
import { AdminProvider, useAdmin } from '@/contexts/AdminContext';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { WhatsAppButton } from '@/components/WhatsAppButton';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { AdminLayout } from '@/components/AdminLayout';

// Lazy load pages
const HomePage = lazy(() => import('@/pages/HomePage'));
const ProductsPage = lazy(() => import('@/pages/ProductsPage'));
const ProductDetailPage = lazy(() => import('@/pages/ProductDetailPage'));
const AboutPage = lazy(() => import('@/pages/AboutPage'));
const PackagingPage = lazy(() => import('@/pages/PackagingPage'));
const ContactPage = lazy(() => import('@/pages/ContactPage'));
const CartPage = lazy(() => import('@/pages/CartPage'));
const CheckoutPage = lazy(() => import('@/pages/CheckoutPage'));
const OrderSuccessPage = lazy(() => import('@/pages/OrderSuccessPage'));
const AdminLoginPage = lazy(() => import('@/pages/AdminLoginPage'));
const AdminDashboardPage = lazy(() => import('@/pages/AdminDashboardPage'));
const AdminProductsPage = lazy(() => import('@/pages/AdminProductsPage'));
const AdminOrdersPage = lazy(() => import('@/pages/AdminOrdersPage'));
const AdminCustomersPage = lazy(() => import('@/pages/AdminCustomersPage'));
const AdminCouponsPage = lazy(() => import('@/pages/AdminCouponsPage'));
const AdminSettingsPage = lazy(() => import('@/pages/AdminSettingsPage'));

const MainLayout: React.FC = () => (
  <div className="flex flex-col min-h-screen">
    <Navbar />
    <main className="flex-1">
      <Suspense fallback={<div className="pt-32 pb-16 flex justify-center"><LoadingSpinner /></div>}>
        <Outlet />
      </Suspense>
    </main>
    <Footer />
    <WhatsAppButton />
  </div>
);

const AdminRouteGuard: React.FC = () => {
  const { isAuthenticated } = useAdmin();
  if (!isAuthenticated) return <Navigate to="/admin/login" replace />;
  return (
    <AdminLayout>
      <Suspense fallback={<div className="p-8 flex justify-center"><LoadingSpinner /></div>}>
        <Outlet />
      </Suspense>
    </AdminLayout>
  );
};

const App: React.FC = () => {
  return (
    <CartProvider>
      <AdminProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route element={<MainLayout />}>
              <Route path="/" element={<HomePage />} />
              <Route path="/products" element={<ProductsPage />} />
              <Route path="/products/:id" element={<ProductDetailPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/packaging" element={<PackagingPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/order-success/:id" element={<OrderSuccessPage />} />
            </Route>

            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route element={<AdminRouteGuard />}>
              <Route path="/admin" element={<AdminDashboardPage />} />
              <Route path="/admin/products" element={<AdminProductsPage />} />
              <Route path="/admin/orders" element={<AdminOrdersPage />} />
              <Route path="/admin/customers" element={<AdminCustomersPage />} />
              <Route path="/admin/coupons" element={<AdminCouponsPage />} />
              <Route path="/admin/settings" element={<AdminSettingsPage />} />
            </Route>

            {/* 404 */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AdminProvider>
    </CartProvider>
  );
};

export default App;
