/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        oasis: {
          50: '#fdf8f0',
          100: '#f9ecd8',
          200: '#f0d5a8',
          300: '#e4b86e',
          400: '#d4a853',
          500: '#c4943a',
          600: '#a8782e',
          700: '#8a5e26',
          800: '#6d4a22',
          900: '#5a3d1f',
          950: '#321f0d',
        },
        sand: {
          50: '#faf8f5',
          100: '#f5f0e8',
          200: '#e8dcc8',
          300: '#d4c4a0',
          400: '#bfa87a',
          500: '#a8905a',
          600: '#8a7448',
          700: '#6d5a38',
          800: '#52452c',
          900: '#3d3321',
        },
        palm: {
          50: '#f0f5e8',
          100: '#dce8cc',
          200: '#b8d19a',
          300: '#8fb86a',
          400: '#6a9f42',
          500: '#4d7f2e',
          600: '#3a6624',
          700: '#2d4f1c',
          800: '#1f3814',
          900: '#14220d',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        arabic: ['Noto Sans Arabic', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
        'scale-in': 'scaleIn 0.3s ease-out',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
};
