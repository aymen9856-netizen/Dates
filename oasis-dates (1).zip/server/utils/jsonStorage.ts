import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

const DATA_DIR = join(process.cwd(), '..', 'data');

function getFilePath(filename: string): string {
  return join(DATA_DIR, filename);
}

function ensureFile(filename: string, defaultContent: object): void {
  const filepath = getFilePath(filename);
  if (!existsSync(filepath)) {
    writeFileSync(filepath, JSON.stringify(defaultContent, null, 2), 'utf-8');
  }
}

export function readJson<T>(filename: string, defaultContent: object = {}): T {
  ensureFile(filename, defaultContent);
  const filepath = getFilePath(filename);
  const content = readFileSync(filepath, 'utf-8');
  return JSON.parse(content) as T;
}

export function writeJson(filename: string, data: unknown): void {
  const filepath = getFilePath(filename);
  writeFileSync(filepath, JSON.stringify(data, null, 2), 'utf-8');
}

export function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
