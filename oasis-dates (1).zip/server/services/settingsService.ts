import { Settings } from '../types/index.js';
import { readJson, writeJson } from '../utils/jsonStorage.js';

interface SettingsData {
  settings: Settings;
}

const defaultSettings: Settings = {
  siteName: 'مزرعة الواحات',
  siteDescription: 'متجر التمور الفاخر - أفضل أنواع التمور السعودية',
  logo: '/uploads/logo.png',
  banner: '/uploads/banner.jpg',
  contact: {
    phone: '+966 55 123 4567',
    whatsapp: '+966 55 123 4567',
    email: 'info@oasis-dates.com',
    address: 'القصيم، المملكة العربية السعودية',
  },
  social: {
    facebook: 'https://facebook.com/oasisdates',
    twitter: 'https://twitter.com/oasisdates',
    instagram: 'https://instagram.com/oasisdates',
    youtube: 'https://youtube.com/oasisdates',
  },
  seo: {
    title: 'مزرعة الواحات - متجر التمور الفاخر',
    description: 'أفضل أنواع التمور السعودية الفاخرة من مزرعة الواحات. تمر سكري، خلاص، صقعي، مجدول وغيرها.',
    keywords: 'تمور، تمر، سكري، خلاص، صقعي، مزرعة الواحات، تمور فاخرة',
  },
};

export class SettingsService {
  static get(): Settings {
    const data = readJson<SettingsData>('settings.json', { settings: defaultSettings });
    return data.settings;
  }

  static update(settings: Partial<Settings>): Settings {
    const current = this.get();
    const updated = { ...current, ...settings };
    writeJson('settings.json', { settings: updated });
    return updated;
  }
}
