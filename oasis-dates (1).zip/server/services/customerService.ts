import { Customer, Address } from '../types/index.js';
import { readJson, writeJson, generateId } from '../utils/jsonStorage.js';

interface CustomersData {
  customers: Customer[];
}

export class CustomerService {
  private static getData(): CustomersData {
    return readJson<CustomersData>('customers.json', { customers: [] });
  }

  private static saveData(data: CustomersData): void {
    writeJson('customers.json', data);
  }

  static getAll(): Customer[] {
    return this.getData().customers;
  }

  static getById(id: string): Customer | undefined {
    const data = this.getData();
    return data.customers.find(c => c.id === id);
  }

  static getByPhone(phone: string): Customer | undefined {
    const data = this.getData();
    return data.customers.find(c => c.phone === phone);
  }

  static create(customer: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>): Customer {
    const data = this.getData();
    const newCustomer: Customer = {
      ...customer,
      id: generateId('cust'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    data.customers.push(newCustomer);
    this.saveData(data);
    return newCustomer;
  }

  static update(id: string, updates: Partial<Customer>): Customer | null {
    const data = this.getData();
    const index = data.customers.findIndex(c => c.id === id);
    if (index === -1) return null;

    data.customers[index] = {
      ...data.customers[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.saveData(data);
    return data.customers[index];
  }

  static addOrder(customerId: string, orderId: string): boolean {
    const data = this.getData();
    const customer = data.customers.find(c => c.id === customerId);
    if (!customer) return false;
    customer.orders.push(orderId);
    customer.updatedAt = new Date().toISOString();
    this.saveData(data);
    return true;
  }

  static toggleFavorite(customerId: string, productId: string): boolean {
    const data = this.getData();
    const customer = data.customers.find(c => c.id === customerId);
    if (!customer) return false;

    const index = customer.favorites.indexOf(productId);
    if (index > -1) {
      customer.favorites.splice(index, 1);
    } else {
      customer.favorites.push(productId);
    }
    customer.updatedAt = new Date().toISOString();
    this.saveData(data);
    return true;
  }

  static getCount(): number {
    return this.getData().customers.length;
  }
}
