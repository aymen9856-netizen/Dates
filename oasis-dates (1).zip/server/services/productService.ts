import { Product } from '../types/index.js';
import { readJson, writeJson, generateId } from '../utils/jsonStorage.js';

interface ProductsData {
  products: Product[];
}

export class ProductService {
  private static getData(): ProductsData {
    return readJson<ProductsData>('products.json', { products: [] });
  }

  private static saveData(data: ProductsData): void {
    writeJson('products.json', data);
  }

  static getAll(): Product[] {
    const data = this.getData();
    return data.products.filter(p => p.status !== 'hidden');
  }

  static getAllAdmin(): Product[] {
    return this.getData().products;
  }

  static getById(id: string): Product | undefined {
    const data = this.getData();
    return data.products.find(p => p.id === id);
  }

  static getFeatured(): Product[] {
    const data = this.getData();
    return data.products.filter(p => p.featured && p.status === 'active');
  }

  static getByCategory(category: string): Product[] {
    const data = this.getData();
    return data.products.filter(p => p.category === category && p.status === 'active');
  }

  static search(query: string): Product[] {
    const data = this.getData();
    const lowerQuery = query.toLowerCase();
    return data.products.filter(p => 
      p.status === 'active' && (
        p.name.toLowerCase().includes(lowerQuery) ||
        p.description.toLowerCase().includes(lowerQuery) ||
        p.category.toLowerCase().includes(lowerQuery) ||
        p.keywords.toLowerCase().includes(lowerQuery) ||
        p.sku.toLowerCase().includes(lowerQuery)
      )
    );
  }

  static create(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'views' | 'sales'>): Product {
    const data = this.getData();
    const newProduct: Product = {
      ...product,
      id: generateId('prod'),
      views: 0,
      sales: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    data.products.push(newProduct);
    this.saveData(data);
    return newProduct;
  }

  static update(id: string, updates: Partial<Product>): Product | null {
    const data = this.getData();
    const index = data.products.findIndex(p => p.id === id);
    if (index === -1) return null;

    data.products[index] = {
      ...data.products[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.saveData(data);
    return data.products[index];
  }

  static delete(id: string): boolean {
    const data = this.getData();
    const index = data.products.findIndex(p => p.id === id);
    if (index === -1) return false;
    data.products.splice(index, 1);
    this.saveData(data);
    return true;
  }

  static incrementViews(id: string): void {
    const data = this.getData();
    const product = data.products.find(p => p.id === id);
    if (product) {
      product.views += 1;
      this.saveData(data);
    }
  }

  static getCategories(): string[] {
    const data = this.getData();
    const categories = new Set(data.products.map(p => p.category));
    return Array.from(categories);
  }

  static getTypes(): string[] {
    const data = this.getData();
    const types = new Set(data.products.map(p => p.type));
    return Array.from(types);
  }

  static getQualities(): string[] {
    const data = this.getData();
    const qualities = new Set(data.products.map(p => p.quality));
    return Array.from(qualities);
  }
}
