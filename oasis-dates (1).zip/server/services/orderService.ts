import { Order, OrderItem } from '../types/index.js';
import { readJson, writeJson, generateId } from '../utils/jsonStorage.js';

interface OrdersData {
  orders: Order[];
}

export class OrderService {
  private static getData(): OrdersData {
    return readJson<OrdersData>('orders.json', { orders: [] });
  }

  private static saveData(data: OrdersData): void {
    writeJson('orders.json', data);
  }

  static getAll(): Order[] {
    return this.getData().orders;
  }

  static getById(id: string): Order | undefined {
    const data = this.getData();
    return data.orders.find(o => o.id === id);
  }

  static getByCustomer(customerId: string): Order[] {
    const data = this.getData();
    return data.orders.filter(o => o.customerId === customerId);
  }

  static create(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Order {
    const data = this.getData();
    const newOrder: Order = {
      ...order,
      id: generateId('ord'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    data.orders.push(newOrder);
    this.saveData(data);
    return newOrder;
  }

  static updateStatus(id: string, status: Order['status']): Order | null {
    const data = this.getData();
    const index = data.orders.findIndex(o => o.id === id);
    if (index === -1) return null;

    data.orders[index].status = status;
    data.orders[index].updatedAt = new Date().toISOString();
    this.saveData(data);
    return data.orders[index];
  }

  static delete(id: string): boolean {
    const data = this.getData();
    const index = data.orders.findIndex(o => o.id === id);
    if (index === -1) return false;
    data.orders.splice(index, 1);
    this.saveData(data);
    return true;
  }

  static getStats() {
    const data = this.getData();
    const orders = data.orders;
    return {
      total: orders.length,
      pending: orders.filter(o => o.status === 'pending').length,
      confirmed: orders.filter(o => o.status === 'confirmed').length,
      preparing: orders.filter(o => o.status === 'preparing').length,
      shipping: orders.filter(o => o.status === 'shipping').length,
      delivered: orders.filter(o => o.status === 'delivered').length,
      cancelled: orders.filter(o => o.status === 'cancelled').length,
      totalRevenue: orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + o.total, 0),
    };
  }

  static getRecent(limit: number = 10): Order[] {
    const data = this.getData();
    return data.orders
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }
}
