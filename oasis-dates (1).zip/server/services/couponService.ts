import { Coupon } from '../types/index.js';
import { readJson, writeJson, generateId } from '../utils/jsonStorage.js';

interface CouponsData {
  coupons: Coupon[];
}

export class CouponService {
  private static getData(): CouponsData {
    return readJson<CouponsData>('coupons.json', { coupons: [] });
  }

  private static saveData(data: CouponsData): void {
    writeJson('coupons.json', data);
  }

  static getAll(): Coupon[] {
    return this.getData().coupons;
  }

  static getById(id: string): Coupon | undefined {
    const data = this.getData();
    return data.coupons.find(c => c.id === id);
  }

  static getByCode(code: string): Coupon | undefined {
    const data = this.getData();
    return data.coupons.find(c => c.code.toLowerCase() === code.toLowerCase());
  }

  static validate(code: string, orderTotal: number): { valid: boolean; discount: number; message: string } {
    const coupon = this.getByCode(code);

    if (!coupon) {
      return { valid: false, discount: 0, message: 'الكوبون غير موجود' };
    }

    if (!coupon.isActive) {
      return { valid: false, discount: 0, message: 'الكوبون غير نشط' };
    }

    const now = new Date();
    if (new Date(coupon.startDate) > now) {
      return { valid: false, discount: 0, message: 'الكوبون لم يبدأ بعد' };
    }
    if (new Date(coupon.endDate) < now) {
      return { valid: false, discount: 0, message: 'الكوبون منتهي الصلاحية' };
    }

    if (coupon.usageCount >= coupon.usageLimit) {
      return { valid: false, discount: 0, message: 'تم استنفاد عدد استخدامات الكوبون' };
    }

    if (orderTotal < coupon.minOrder) {
      return { valid: false, discount: 0, message: `الحد الأدنى للطلب ${coupon.minOrder} ريال` };
    }

    let discount = 0;
    if (coupon.type === 'percentage') {
      discount = (orderTotal * coupon.value) / 100;
      if (coupon.maxDiscount > 0) {
        discount = Math.min(discount, coupon.maxDiscount);
      }
    } else {
      discount = coupon.value;
    }

    return { valid: true, discount, message: 'الكوبون صالح' };
  }

  static use(code: string): boolean {
    const data = this.getData();
    const coupon = data.coupons.find(c => c.code.toLowerCase() === code.toLowerCase());
    if (!coupon) return false;
    coupon.usageCount += 1;
    this.saveData(data);
    return true;
  }

  static create(coupon: Omit<Coupon, 'id' | 'createdAt' | 'usageCount'>): Coupon {
    const data = this.getData();
    const newCoupon: Coupon = {
      ...coupon,
      id: generateId('coup'),
      usageCount: 0,
      createdAt: new Date().toISOString(),
    };
    data.coupons.push(newCoupon);
    this.saveData(data);
    return newCoupon;
  }

  static update(id: string, updates: Partial<Coupon>): Coupon | null {
    const data = this.getData();
    const index = data.coupons.findIndex(c => c.id === id);
    if (index === -1) return null;

    data.coupons[index] = { ...data.coupons[index], ...updates };
    this.saveData(data);
    return data.coupons[index];
  }

  static delete(id: string): boolean {
    const data = this.getData();
    const index = data.coupons.findIndex(c => c.id === id);
    if (index === -1) return false;
    data.coupons.splice(index, 1);
    this.saveData(data);
    return true;
  }
}
