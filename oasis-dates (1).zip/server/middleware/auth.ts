import { Request, Response, NextFunction } from 'express';
import { readJson } from '../utils/jsonStorage.js';
import { logger } from '../utils/logger.js';

interface AdminSession {
  id: string;
  token: string;
  createdAt: string;
  expiresAt: string;
}

interface SessionsData {
  sessions: AdminSession[];
}

export const authenticateAdmin = (req: Request, res: Response, next: NextFunction): void => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') 
      ? authHeader.slice(7) 
      : req.cookies?.adminToken;

    if (!token) {
      res.status(401).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const data = readJson<SessionsData>('sessions.json', { sessions: [] });
    const session = data.sessions.find(s => s.token === token && new Date(s.expiresAt) > new Date());

    if (!session) {
      res.status(401).json({ success: false, message: 'Session expired' });
      return;
    }

    next();
  } catch (error) {
    logger.error('Auth middleware error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};
