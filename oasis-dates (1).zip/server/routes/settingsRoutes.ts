import { Router } from 'express';
import { SettingsController } from '../controllers/settingsController.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', SettingsController.get);
router.put('/', authenticateAdmin, SettingsController.update);

export default router;
