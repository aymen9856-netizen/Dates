import { Router } from 'express';
import { CustomerController } from '../controllers/customerController.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', authenticateAdmin, CustomerController.getAll);
router.get('/:id', authenticateAdmin, CustomerController.getById);
router.post('/', CustomerController.create);

export default router;
