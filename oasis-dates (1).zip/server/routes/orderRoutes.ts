import { Router } from 'express';
import { OrderController } from '../controllers/orderController.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', authenticateAdmin, OrderController.getAll);
router.get('/:id', OrderController.getById);
router.post('/', OrderController.create);
router.patch('/:id/status', authenticateAdmin, OrderController.updateStatus);
router.delete('/:id', authenticateAdmin, OrderController.delete);
router.get('/:id/invoice', OrderController.getInvoice);

export default router;
