import { Router } from 'express';
import { CouponController } from '../controllers/couponController.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', authenticateAdmin, CouponController.getAll);
router.get('/validate', CouponController.validate);
router.post('/', authenticateAdmin, CouponController.create);
router.put('/:id', authenticateAdmin, CouponController.update);
router.delete('/:id', authenticateAdmin, CouponController.delete);

export default router;
