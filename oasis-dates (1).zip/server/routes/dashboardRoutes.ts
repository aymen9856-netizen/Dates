import { Router } from 'express';
import { DashboardController } from '../controllers/dashboardController.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/stats', authenticateAdmin, DashboardController.getStats);
router.get('/recent-orders', authenticateAdmin, DashboardController.getRecentOrders);
router.get('/top-products', authenticateAdmin, DashboardController.getTopProducts);

export default router;
