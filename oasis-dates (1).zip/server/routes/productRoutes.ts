import { Router } from 'express';
import { ProductController } from '../controllers/productController.js';
import { upload } from '../middleware/upload.js';
import { authenticateAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', ProductController.getAll);
router.get('/admin', authenticateAdmin, ProductController.getAllAdmin);
router.get('/featured', ProductController.getFeatured);
router.get('/categories', ProductController.getCategories);
router.get('/search', ProductController.search);
router.get('/:id', ProductController.getById);
router.post('/', authenticateAdmin, upload.array('images', 10), ProductController.create);
router.put('/:id', authenticateAdmin, upload.array('images', 10), ProductController.update);
router.delete('/:id', authenticateAdmin, ProductController.delete);

export default router;
