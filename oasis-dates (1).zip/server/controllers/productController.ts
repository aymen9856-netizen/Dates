import { Request, Response } from 'express';
import { ProductService } from '../services/productService.js';
import { logger } from '../utils/logger.js';

export const ProductController = {
  getAll: (_req: Request, res: Response): void => {
    try {
      const products = ProductService.getAll();
      res.json({ success: true, data: products });
    } catch (error) {
      logger.error('Error getting products:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getAllAdmin: (_req: Request, res: Response): void => {
    try {
      const products = ProductService.getAllAdmin();
      res.json({ success: true, data: products });
    } catch (error) {
      logger.error('Error getting admin products:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getById: (req: Request, res: Response): void => {
    try {
      const product = ProductService.getById(req.params.id);
      if (!product) {
        res.status(404).json({ success: false, message: 'Product not found' });
        return;
      }
      ProductService.incrementViews(req.params.id);
      res.json({ success: true, data: product });
    } catch (error) {
      logger.error('Error getting product:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getFeatured: (_req: Request, res: Response): void => {
    try {
      const products = ProductService.getFeatured();
      res.json({ success: true, data: products });
    } catch (error) {
      logger.error('Error getting featured products:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getCategories: (_req: Request, res: Response): void => {
    try {
      const categories = ProductService.getCategories();
      res.json({ success: true, data: categories });
    } catch (error) {
      logger.error('Error getting categories:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  search: (req: Request, res: Response): void => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        res.status(400).json({ success: false, message: 'Query parameter required' });
        return;
      }
      const products = ProductService.search(q);
      res.json({ success: true, data: products });
    } catch (error) {
      logger.error('Error searching products:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  create: (req: Request, res: Response): void => {
    try {
      const files = req.files as Express.Multer.File[];
      const images = files?.map(f => `/uploads/products/${f.filename}`) || [];

      const product = ProductService.create({
        ...req.body,
        images: images.length > 0 ? images : req.body.images || [],
        mainImage: images[0] || req.body.mainImage || '',
        price: Number(req.body.price),
        oldPrice: req.body.oldPrice ? Number(req.body.oldPrice) : null,
        stock: Number(req.body.stock),
        featured: req.body.featured === 'true' || req.body.featured === true,
      });

      res.status(201).json({ success: true, data: product });
    } catch (error) {
      logger.error('Error creating product:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  update: (req: Request, res: Response): void => {
    try {
      const files = req.files as Express.Multer.File[];
      const newImages = files?.map(f => `/uploads/products/${f.filename}`) || [];

      const existingProduct = ProductService.getById(req.params.id);
      if (!existingProduct) {
        res.status(404).json({ success: false, message: 'Product not found' });
        return;
      }

      const updates: Record<string, unknown> = { ...req.body };

      if (newImages.length > 0) {
        updates.images = [...existingProduct.images, ...newImages];
        if (!updates.mainImage) updates.mainImage = newImages[0];
      }

      if (req.body.price) updates.price = Number(req.body.price);
      if (req.body.oldPrice !== undefined) updates.oldPrice = req.body.oldPrice ? Number(req.body.oldPrice) : null;
      if (req.body.stock) updates.stock = Number(req.body.stock);
      if (req.body.featured !== undefined) updates.featured = req.body.featured === 'true' || req.body.featured === true;

      const product = ProductService.update(req.params.id, updates);
      res.json({ success: true, data: product });
    } catch (error) {
      logger.error('Error updating product:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  delete: (req: Request, res: Response): void => {
    try {
      const success = ProductService.delete(req.params.id);
      if (!success) {
        res.status(404).json({ success: false, message: 'Product not found' });
        return;
      }
      res.json({ success: true, message: 'Product deleted' });
    } catch (error) {
      logger.error('Error deleting product:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
