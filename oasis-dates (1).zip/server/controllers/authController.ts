import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { readJson, writeJson } from '../utils/jsonStorage.js';
import { logger } from '../utils/logger.js';

const ADMIN_PASSWORD_HASH = '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; // hash of "0667322104"

interface Session {
  id: string;
  token: string;
  createdAt: string;
  expiresAt: string;
}

interface SessionsData {
  sessions: Session[];
}

export const AuthController = {
  login: async (req: Request, res: Response): Promise<void> => {
    try {
      const { password } = req.body;

      if (!password) {
        res.status(400).json({ success: false, message: 'Password required' });
        return;
      }

      const isValid = await bcrypt.compare(password, ADMIN_PASSWORD_HASH);

      if (!isValid) {
        res.status(401).json({ success: false, message: 'Invalid password' });
        return;
      }

      const token = uuidv4();
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

      const data = readJson<SessionsData>('sessions.json', { sessions: [] });
      data.sessions.push({
        id: uuidv4(),
        token,
        createdAt: new Date().toISOString(),
        expiresAt,
      });
      writeJson('sessions.json', data);

      res.json({ success: true, data: { token } });
    } catch (error) {
      logger.error('Login error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  logout: (req: Request, res: Response): void => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

      if (token) {
        const data = readJson<SessionsData>('sessions.json', { sessions: [] });
        data.sessions = data.sessions.filter(s => s.token !== token);
        writeJson('sessions.json', data);
      }

      res.json({ success: true, message: 'Logged out' });
    } catch (error) {
      logger.error('Logout error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  check: (req: Request, res: Response): void => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

      if (!token) {
        res.status(401).json({ success: false, message: 'No token' });
        return;
      }

      const data = readJson<SessionsData>('sessions.json', { sessions: [] });
      const session = data.sessions.find(s => s.token === token && new Date(s.expiresAt) > new Date());

      if (!session) {
        res.status(401).json({ success: false, message: 'Session expired' });
        return;
      }

      res.json({ success: true, data: { valid: true } });
    } catch (error) {
      logger.error('Auth check error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
