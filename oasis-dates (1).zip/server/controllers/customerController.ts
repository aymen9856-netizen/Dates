import { Request, Response } from 'express';
import { CustomerService } from '../services/customerService.js';
import { logger } from '../utils/logger.js';

export const CustomerController = {
  getAll: (_req: Request, res: Response): void => {
    try {
      const customers = CustomerService.getAll();
      res.json({ success: true, data: customers });
    } catch (error) {
      logger.error('Error getting customers:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getById: (req: Request, res: Response): void => {
    try {
      const customer = CustomerService.getById(req.params.id);
      if (!customer) {
        res.status(404).json({ success: false, message: 'Customer not found' });
        return;
      }
      res.json({ success: true, data: customer });
    } catch (error) {
      logger.error('Error getting customer:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  create: (req: Request, res: Response): void => {
    try {
      const customer = CustomerService.create(req.body);
      res.status(201).json({ success: true, data: customer });
    } catch (error) {
      logger.error('Error creating customer:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
