import { Request, Response } from 'express';
import { ProductService } from '../services/productService.js';
import { OrderService } from '../services/orderService.js';
import { CustomerService } from '../services/customerService.js';
import { logger } from '../utils/logger.js';

export const DashboardController = {
  getStats: (_req: Request, res: Response): void => {
    try {
      const products = ProductService.getAllAdmin();
      const orderStats = OrderService.getStats();

      res.json({
        success: true,
        data: {
          totalProducts: products.length,
          totalOrders: orderStats.total,
          totalCustomers: CustomerService.getCount(),
          totalRevenue: orderStats.totalRevenue,
          pendingOrders: orderStats.pending,
          lowStock: products.filter(p => p.stock < 20).length,
        },
      });
    } catch (error) {
      logger.error('Dashboard stats error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getRecentOrders: (_req: Request, res: Response): void => {
    try {
      const orders = OrderService.getRecent(10);
      res.json({ success: true, data: orders });
    } catch (error) {
      logger.error('Recent orders error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getTopProducts: (_req: Request, res: Response): void => {
    try {
      const products = ProductService.getAllAdmin()
        .sort((a, b) => b.sales - a.sales)
        .slice(0, 10);
      res.json({ success: true, data: products });
    } catch (error) {
      logger.error('Top products error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
