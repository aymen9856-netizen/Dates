import { Request, Response } from 'express';
import { CouponService } from '../services/couponService.js';
import { logger } from '../utils/logger.js';

export const CouponController = {
  getAll: (_req: Request, res: Response): void => {
    try {
      const coupons = CouponService.getAll();
      res.json({ success: true, data: coupons });
    } catch (error) {
      logger.error('Error getting coupons:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  validate: (req: Request, res: Response): void => {
    try {
      const { code, total } = req.query;
      if (!code || !total) {
        res.status(400).json({ success: false, message: 'Code and total required' });
        return;
      }
      const result = CouponService.validate(String(code), Number(total));
      res.json({ success: true, data: result });
    } catch (error) {
      logger.error('Error validating coupon:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  create: (req: Request, res: Response): void => {
    try {
      const coupon = CouponService.create(req.body);
      res.status(201).json({ success: true, data: coupon });
    } catch (error) {
      logger.error('Error creating coupon:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  update: (req: Request, res: Response): void => {
    try {
      const coupon = CouponService.update(req.params.id, req.body);
      if (!coupon) {
        res.status(404).json({ success: false, message: 'Coupon not found' });
        return;
      }
      res.json({ success: true, data: coupon });
    } catch (error) {
      logger.error('Error updating coupon:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  delete: (req: Request, res: Response): void => {
    try {
      const success = CouponService.delete(req.params.id);
      if (!success) {
        res.status(404).json({ success: false, message: 'Coupon not found' });
        return;
      }
      res.json({ success: true, message: 'Coupon deleted' });
    } catch (error) {
      logger.error('Error deleting coupon:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
