import { Request, Response } from 'express';
import { SettingsService } from '../services/settingsService.js';
import { logger } from '../utils/logger.js';

export const SettingsController = {
  get: (_req: Request, res: Response): void => {
    try {
      const settings = SettingsService.get();
      res.json({ success: true, data: settings });
    } catch (error) {
      logger.error('Settings get error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  update: (req: Request, res: Response): void => {
    try {
      const settings = SettingsService.update(req.body);
      res.json({ success: true, data: settings });
    } catch (error) {
      logger.error('Settings update error:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
