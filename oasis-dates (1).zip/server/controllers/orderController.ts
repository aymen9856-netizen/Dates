import { Request, Response } from 'express';
import { OrderService } from '../services/orderService.js';
import { CustomerService } from '../services/customerService.js';
import { ProductService } from '../services/productService.js';
import { logger } from '../utils/logger.js';
import type { Order } from '../types/index.js';

export const OrderController = {
  getAll: (_req: Request, res: Response): void => {
    try {
      const orders = OrderService.getAll();
      res.json({ success: true, data: orders });
    } catch (error) {
      logger.error('Error getting orders:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getById: (req: Request, res: Response): void => {
    try {
      const order = OrderService.getById(req.params.id);
      if (!order) {
        res.status(404).json({ success: false, message: 'Order not found' });
        return;
      }
      res.json({ success: true, data: order });
    } catch (error) {
      logger.error('Error getting order:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  create: (req: Request, res: Response): void => {
    try {
      const { customerName, customerPhone, customerEmail, items, subtotal, discount, shipping, total, address, city, notes } = req.body;

      // Check stock
      for (const item of items) {
        const product = ProductService.getById(item.productId);
        if (!product) {
          res.status(400).json({ success: false, message: `Product ${item.productId} not found` });
          return;
        }
        if (product.stock < item.quantity) {
          res.status(400).json({ success: false, message: `Insufficient stock for ${product.name}` });
          return;
        }
      }

      // Update stock
      for (const item of items) {
        const product = ProductService.getById(item.productId);
        if (product) {
          ProductService.update(item.productId, { 
            stock: product.stock - item.quantity,
            sales: product.sales + item.quantity 
          });
        }
      }

      // Find or create customer
      let customer = CustomerService.getByPhone(customerPhone);
      if (!customer) {
        customer = CustomerService.create({
          name: customerName,
          phone: customerPhone,
          email: customerEmail || '',
          addresses: address ? [{ id: `addr_${Date.now()}`, label: 'الرئيسي', address, city, isDefault: true }] : [],
          orders: [],
          favorites: [],
        });
      }

      const order = OrderService.create({
        customerId: customer.id,
        customerName,
        customerPhone,
        customerEmail: customerEmail || '',
        items,
        subtotal,
        discount: discount || 0,
        shipping,
        total,
        status: 'pending',
        address,
        city,
        notes: notes || '',
        couponCode: null,
      });

      CustomerService.addOrder(customer.id, order.id);

      res.status(201).json({ success: true, data: order });
    } catch (error) {
      logger.error('Error creating order:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  updateStatus: (req: Request, res: Response): void => {
    try {
      const { status } = req.body;
      const order = OrderService.updateStatus(req.params.id, status);
      if (!order) {
        res.status(404).json({ success: false, message: 'Order not found' });
        return;
      }
      res.json({ success: true, data: order });
    } catch (error) {
      logger.error('Error updating order status:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  delete: (req: Request, res: Response): void => {
    try {
      const success = OrderService.delete(req.params.id);
      if (!success) {
        res.status(404).json({ success: false, message: 'Order not found' });
        return;
      }
      res.json({ success: true, message: 'Order deleted' });
    } catch (error) {
      logger.error('Error deleting order:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  getInvoice: (req: Request, res: Response): void => {
    try {
      const order = OrderService.getById(req.params.id);
      if (!order) {
        res.status(404).json({ success: false, message: 'Order not found' });
        return;
      }

      // Simple HTML invoice
      const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <title>فاتورة #${order.id}</title>
  <style>
    body { font-family: 'Segoe UI', sans-serif; margin: 40px; background: #faf8f5; }
    .invoice { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
    .header { text-align: center; border-bottom: 3px solid #d4a853; padding-bottom: 20px; margin-bottom: 30px; }
    .header h1 { color: #1a1a2e; margin: 0; }
    .header p { color: #666; margin: 5px 0; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
    .info-box { background: #f9ecd8; padding: 15px; border-radius: 8px; }
    .info-box h3 { margin: 0 0 10px 0; color: #8a5e26; font-size: 14px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    th { background: #1a1a2e; color: white; padding: 12px; text-align: right; }
    td { padding: 12px; border-bottom: 1px solid #eee; }
    .total { text-align: left; font-size: 18px; font-weight: bold; color: #1a1a2e; }
    .footer { text-align: center; margin-top: 40px; color: #999; font-size: 12px; }
    @media print { body { background: white; } .invoice { box-shadow: none; } }
  </style>
</head>
<body>
  <div class="invoice">
    <div class="header">
      <h1>مزرعة الواحات</h1>
      <p>متجر التمور الفاخر</p>
      <p>فاتورة طلب #${order.id.slice(0, 12)}</p>
    </div>

    <div class="info-grid">
      <div class="info-box">
        <h3>العميل</h3>
        <p><strong>${order.customerName}</strong></p>
        <p>${order.customerPhone}</p>
        <p>${order.customerEmail}</p>
      </div>
      <div class="info-box">
        <h3>الطلب</h3>
        <p>التاريخ: ${new Date(order.createdAt).toLocaleDateString('ar-SA')}</p>
        <p>الحالة: ${order.status}</p>
        <p>العنوان: ${order.address}, ${order.city}</p>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>المنتج</th>
          <th>الوزن</th>
          <th>الكمية</th>
          <th>السعر</th>
          <th>الإجمالي</th>
        </tr>
      </thead>
      <tbody>
        ${order.items.map(item => `
        <tr>
          <td>${item.name}</td>
          <td>${item.weight}</td>
          <td>${item.quantity}</td>
          <td>${item.price.toFixed(2)} ر.س</td>
          <td>${(item.price * item.quantity).toFixed(2)} ر.س</td>
        </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="total">
      <p>المجموع الفرعي: ${order.subtotal.toFixed(2)} ر.س</p>
      ${order.discount > 0 ? `<p>الخصم: ${order.discount.toFixed(2)} ر.س</p>` : ''}
      <p>الشحن: ${order.shipping === 0 ? 'مجاني' : `${order.shipping.toFixed(2)} ر.س`}</p>
      <p style="font-size: 24px; color: #d4a853;">الإجمالي: ${order.total.toFixed(2)} ر.س</p>
    </div>

    <div class="footer">
      <p>شكراً لثقتكم بمزرعة الواحات</p>
      <p>للاستفسارات: info@oasis-dates.com | +966 55 123 4567</p>
    </div>
  </div>
  <script>window.onload = () => window.print();</script>
</body>
</html>`;

      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(html);
    } catch (error) {
      logger.error('Error generating invoice:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};
