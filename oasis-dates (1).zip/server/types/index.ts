export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice: number | null;
  weight: string;
  category: string;
  type: string;
  quality: string;
  country: string;
  region: string;
  stock: number;
  sku: string;
  barcode: string;
  keywords: string;
  status: 'active' | 'inactive' | 'hidden';
  views: number;
  sales: number;
  images: string[];
  mainImage: string;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  weight: string;
  image: string;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'shipping' | 'delivered' | 'cancelled';
  address: string;
  city: string;
  notes: string;
  couponCode: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  addresses: Address[];
  orders: string[];
  favorites: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Address {
  id: string;
  label: string;
  address: string;
  city: string;
  isDefault: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrder: number;
  maxDiscount: number;
  usageLimit: number;
  usageCount: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  createdAt: string;
}

export interface Settings {
  siteName: string;
  siteDescription: string;
  logo: string;
  banner: string;
  contact: {
    phone: string;
    whatsapp: string;
    email: string;
    address: string;
  };
  social: {
    facebook: string;
    twitter: string;
    instagram: string;
    youtube: string;
  };
  seo: {
    title: string;
    description: string;
    keywords: string;
  };
}

export interface AdminSession {
  id: string;
  token: string;
  createdAt: string;
  expiresAt: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}
