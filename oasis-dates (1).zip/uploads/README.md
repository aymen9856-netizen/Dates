# Placeholder Images

This directory should contain the following images:

## Products (uploads/products/)
- sukkari-crushed-1.jpg
- sukkari-crushed-2.jpg
- sukkari-premium-1.jpg
- khalas-crushed-1.jpg
- barhi-premium-1.jpg
- sagai-premium-1.jpg
- majduul-premium-1.jpg
- sukkari-rutab-1.jpg
- majhoul-premium-1.jpg

## Hero & About (uploads/)
- hero-dates.jpg
- about-farm.jpg
- logo.png
- banner.jpg
- og-image.jpg

You can replace these with your actual product images.
The app will show emoji placeholders if images are missing.
