# 🌴 مزرعة الواحات - متجر التمور الفاخر

<p align="center">
  <img src="https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white" />
  <img src="https://img.shields.io/badge/TypeScript-5.6-3178C6?logo=typescript&logoColor=white" />
  <img src="https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white" />
  <img src="https://img.shields.io/badge/Tailwind-3.4-06B6D4?logo=tailwindcss&logoColor=white" />
  <img src="https://img.shields.io/badge/Node.js-20-339933?logo=node.js&logoColor=white" />
  <img src="https://img.shields.io/badge/Express-4-000000?logo=express&logoColor=white" />
</p>

متجر إلكتروني احترافي متخصص في بيع التمور الفاخرة من مزرعة الواحات في منطقة القصيم، المملكة العربية السعودية.

## ✨ المميزات

### المتجر
- 🛍️ تصفح منتجات التمور المتنوعة (سكري، خلاص، صقعي، مجدول، برحي، مجهول)
- 🔍 بحث لحظي مع فلترة متقدمة (السعر، الوزن، الجودة، التصنيف)
- 🛒 سلة مشتريات مع كوبونات خصم
- 📦 نظام طلبات كامل مع تتبع الحالة
- 📱 تصميم متجاوب 100% (موبايل، تابلت، ديسكتوب)
- 🎨 تصميم فاخر مستوحى من ألوان النخيل والصحراء
- 🔗 مشاركة المنتجات (نسخ الرابط، واتساب)
- 📸 معرض صور احترافي مع تكبير
- 💬 زر واتساب ثابت في جميع الصفحات

### لوحة الإدارة
- 📊 Dashboard مع إحصائيات ورسوم بيانية
- 📦 إدارة المنتجات (إضافة، تعديل، حذف، إخفاء)
- 📋 إدارة الطلبات مع تغيير الحالة
- 👥 إدارة العملاء
- 🏷️ نظام كوبونات خصم احترافي
- ⚙️ إعدادات الموقع (بدون تعديل الكود)
- 🔐 مصادقة آمنة مع Hash
- 📝 فواتير PDF قابلة للطباعة

### الأمان
- 🛡️ Helmet لحماية HTTP headers
- 🚦 Rate Limiting
- 🔒 CORS محدود
- 🔑 Hash للكلمات المرورية (bcrypt)
- ⏰ انتهاء الجلسة بعد فترة الخمول

### SEO
- 🏷️ Meta Tags ديناميكية
- 📱 Open Graph & Twitter Cards
- 🗺️ Sitemap & Robots.txt
- 📐 Schema.org Structured Data
- 🔗 Canonical URLs

## 🚀 التشغيل

### المتطلبات
- Node.js 20+
- npm 10+

### 1. استنساخ المشروع
```bash
git clone https://github.com/your-username/oasis-dates.git
cd oasis-dates
```

### 2. تثبيت الاعتماديات

**السيرفر:**
```bash
cd server
npm install
```

**العميل:**
```bash
cd client
npm install
```

### 3. التشغيل

**تشغيل السيرفر (PORT 5000):**
```bash
cd server
npm run dev
```

**تشغيل العميل (PORT 3000):** - في طرفية أخرى
```bash
cd client
npm run dev
```

### 4. الوصول
- 🌐 الموقع: http://localhost:3000
- 🔧 API: http://localhost:5000
- 🔐 لوحة الإدارة: http://localhost:3000/admin
  - كلمة المرور: `0667322104`

## 📁 هيكل المشروع

```
oasis-dates/
├── client/                 # React Frontend
│   ├── src/
│   │   ├── components/     # المكونات المشتركة
│   │   ├── contexts/       # سياقات React (Cart, Admin)
│   │   ├── pages/          # صفحات التطبيق
│   │   ├── utils/          # أدوات مساعدة (API, SEO, Format)
│   │   ├── types/          # أنواع TypeScript
│   │   └── styles/         # أنماط CSS
│   ├── public/             # ملفات ثابتة
│   └── package.json
│
├── server/                 # Node.js Backend
│   ├── controllers/        # منطق التحكم
│   ├── middleware/         # الوسائط (Auth, Upload, Error)
│   ├── routes/             # مسارات API
│   ├── services/           # طبقة الخدمات (Repository Pattern)
│   ├── utils/              # أدوات (JSON Storage, Logger)
│   ├── types/              # أنواع TypeScript
│   └── server.ts           # نقطة البداية
│
├── data/                   # تخزين JSON
│   ├── products.json
│   ├── orders.json
│   ├── customers.json
│   ├── coupons.json
│   └── settings.json
│
├── uploads/                # الصور
│   ├── products/
│   ├── banners/
│   └── gallery/
│
└── logs/                   # سجلات الأخطاء
```

## 🔧 البناء للإنتاج

### 1. بناء العميل
```bash
cd client
npm run build
```

### 2. تشغيل السيرفر في وضع الإنتاج
```bash
cd server
npm run build
NODE_ENV=production npm start
```

## 🐳 Docker (اختياري)

```dockerfile
# Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY server/package*.json ./
RUN npm ci --only=production
COPY server/ ./
COPY client/dist/ ./public/
EXPOSE 5000
CMD ["node", "dist/server.js"]
```

## 📝 API Endpoints

### المنتجات
| Method | Endpoint | الوصف |
|--------|----------|-------|
| GET | `/api/products` | جميع المنتجات |
| GET | `/api/products/:id` | تفاصيل منتج |
| GET | `/api/products/featured` | المنتجات المميزة |
| GET | `/api/products/search?q=` | البحث |
| POST | `/api/products` | إضافة منتج (Admin) |
| PUT | `/api/products/:id` | تعديل منتج (Admin) |
| DELETE | `/api/products/:id` | حذف منتج (Admin) |

### الطلبات
| Method | Endpoint | الوصف |
|--------|----------|-------|
| GET | `/api/orders` | جميع الطلبات (Admin) |
| GET | `/api/orders/:id` | تفاصيل طلب |
| POST | `/api/orders` | إنشاء طلب |
| PATCH | `/api/orders/:id/status` | تحديث الحالة (Admin) |
| GET | `/api/orders/:id/invoice` | فاتورة PDF |

### المصادقة
| Method | Endpoint | الوصف |
|--------|----------|-------|
| POST | `/api/auth/login` | تسجيل الدخول |
| POST | `/api/auth/logout` | تسجيل الخروج |
| GET | `/api/auth/check` | التحقق من الجلسة |

## 🎨 الألوان

| اللون | الكود | الاستخدام |
|-------|-------|----------|
| Oasis Gold | `#d4a853` | الأزرار الرئيسية، التمييز |
| Oasis Dark | `#1a1a2e` | الخلفيات الداكنة |
| Sand | `#faf8f5` | خلفيات فاتحة |
| Palm Green | `#4d7f2e` | العناصر الطبيعية |

## 🧪 الاختبار

```bash
# اختبار البناء
cd client && npm run build

# اختبار TypeScript
cd server && npx tsc --noEmit
```

## 📄 الترخيص

هذا المشروع مخصص لمزرعة الواحات. جميع الحقوق محفوظة.

## 🤝 الدعم

للاستفسارات والدعم:
- 📧 info@oasis-dates.com
- 📱 +966 55 123 4567
- 💬 واتساب: +966 55 123 4567

---

<p align="center">
  صنع بـ ❤️ في المملكة العربية السعودية
</p>
